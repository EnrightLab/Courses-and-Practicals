


reaper <- function(pdata,geometry,...) {

   cat(paste("\nStart", date(), "\n"), file="reaperlog.txt", append=TRUE)
   status <- 0

   if(sum(colnames(pdata)=="filename")==0){
      stop("Error: the pdata object needs to have a filename column")
   }
   if(sum(colnames(pdata)=="samplename")==0){
      stop("Error: the pdata object needs to have a samplename column")
   }
   if(sum(colnames(pdata)=="barcode")==0){
      pdata[,"barcode"]<- "lane"
   }
   if(sum(colnames(pdata)=="5p-si")==0){
      pdata[,"5p-si"]<- ""
   }
   if(sum(colnames(pdata)=="tabu")==0){
      pdata[,"tabu"]<- ""
   }


   levs <- levels(as.factor(pdata[,"filename"]))
   rfiles <- c()
   tfiles <- c()
   filemap <- c()

   for (i in seq_along(levs)) {

      currfile<-levs[i]
      metafile<- paste("metadata",i,".txt",sep="")

      write.table(pdata[pdata["filename"]==currfile,(colnames(pdata) != "samplename") & (colnames(pdata) != "filename")],file=metafile,row.names=FALSE,quote=FALSE,sep="\t")

      print(paste("Starting Reaper for file:",currfile))
      print(c(fastq=currfile,geom=geometry,meta=metafile,basename=i,...))

      status <- reap(c(fastq=currfile,geom=geometry,meta=metafile,basename=i,...))
      if (status > 0) {
         break
      }

      currfile_barcodes <- pdata[pdata["filename"]==currfile,"barcode"]

      for (bc in currfile_barcodes) {

         talin  <- paste(i,".",bc,".clean.gz",sep="")
         talout <- paste(i,".",bc,".clean.uniq.gz",sep="")
         rfiles <- c(rfiles, talin)
         tfiles <- c(tfiles, talout)
         if (bc == "lane") {
            filemap[currfile] <- paste(i, ".lane", sep="")
         } else {
            filemap[paste(currfile, bc, sep="-=+=-")] <- paste(i, ".", bc, sep="")
         }
         print(paste("Starting Tally for file",currfile, "and barcode:", bc))
         status <- tally(c(i=talin, o=talout))
         if (status > 0) {
            break
         }
      }
      if (status > 0) {
         break
      }
   }

   # print("Reaper output files:")
   # print(rfiles)
   # print("Tally output files:")
   # print(tfiles)

   if (status == 0) {
      for (n in names(filemap)) {
         levels <- unlist(strsplit(n, "-=+=-", fixed=TRUE))
         if (length(levels) > 1) {
            print(paste("Results for file", levels[1], "and barcode", levels[2], "start with", filemap[n]))
         } else {
            print(paste("Results for file", n, "start with", filemap[n]))
         }
      }
   }
   else {
      print("Run failed.")
   }
   cat("End\n\n", file="reaperlog.txt", append=TRUE)
   return(status)
}


reaperQC <- function(pdata){

   if (!"filename" %in% colnames(pdata)) {
      stop("Error: the pdata object needs to have a filename column")
   }
   if(!"samplename" %in% colnames(pdata)) {
      stop("Error: the pdata object needs to have a samplename column")
   }
   if(!"barcode" %in% colnames(pdata)) {
      pdata[,"barcode"]<- "lane"
   }

   levs <- levels(as.factor(pdata[,"filename"]))

   for (i in seq_along(levs)) {

      currfile <- levs[i]

      if (dev.interactive()==TRUE){
        dev.new();
      }
      oldpar <- par(oma=c(0,0,2,0), mar=c(3,3,3,1), mfrow=c(length(pdata[pdata["filename"]==currfile,"barcode"]),3))
      currfile_barcodes <- pdata[pdata["filename"] == currfile, "barcode"]
      currfile_names    <- pdata[pdata["filename"] == currfile, "samplename"]

      for (k in seq_along(currfile_barcodes)) {
      
         bc <- currfile_barcodes[k]
         sn <- currfile_names[k]

         print(paste("Processing Reaper Results for:", currfile,"",bc))

         nt<-paste(i, ".", bc, ".report.input.nt", sep="")
         qual<-paste(i, ".", bc, ".report.input.q", sep="")
         len<-paste(i, ".", bc, ".report.clean.len", sep="")

         reaperBaseCompPlot(nt,paste(sn,bc))
         reaperQualityPlot(qual,paste(sn,bc))
         reaperLengthPlot(len,paste(sn,bc))
         mtext(currfile, outer=TRUE, cex=1.0)
      }
   }
   par(oldpar)
}

reap <- function(theargs) {

	if(!is.character(theargs) || length(theargs) != length(names(theargs)) || sum(names(theargs) == "") > 0) {
      cat("The argument to reaper() must be a named character vector; e.g\n")
      cat("c(geom=\"3p-bc\",  meta=\"mydata.meta\")\n")
      stop("Incorrect format of arguments")
   }

   unary_args_on <-  theargs == "on" | theargs == "ON"
   unary_args_off <- theargs == "off"
   args_other    <-  !(unary_args_on | unary_args_off)

   names(theargs)[unary_args_on] <- paste("--", names(theargs)[unary_args_on], sep="")
   names(theargs)[args_other]    <- paste("-",  names(theargs)[args_other], sep="")
   theargs_reaper <<- c("--R"="on", theargs[unary_args_on | args_other])

	.Call("reaperC",n=theargs_reaper,PACKAGE="Reaper");
   # print(theargs)
}

tally <- function(theargs)
{
	if(!is.character(theargs) || length(theargs) != length(names(theargs)) || sum(names(theargs) == "") > 0) {
      cat("The argument to tally() must be a named character vector; e.g\n")
      cat("c(i=\"out.lane.clean\",  o=\"out.lane.tally\")\n")
      stop("Incorrect format of arguments")
   }

   unary_args_on <-  theargs == "on" | theargs == "ON"
   unary_args_off <- theargs == "off"
   args_other    <-  !(unary_args_on | unary_args_off)

   names(theargs)[unary_args_on] <- paste("--", names(theargs)[unary_args_on], sep="")
   names(theargs)[args_other]    <- paste("-",  names(theargs)[args_other], sep="")
   theargs_tally <<- c("--R"="on", "--with-quality"="on", "-zip-factor"="1", theargs[unary_args_on | args_other])

	.Call("tallyC",n=theargs_tally,PACKAGE="Reaper")
   # print(theargs)
}

reaperQualityPlot <- function(inQualFile, titleQ){
      quants2plot <- c("q10","q50","q90")                                                                   # Selected quantiles plotted by function
      qualTable <- read.delim(inQualFile, quote = "", row.names = 1, 
                             colClasses = c("character","numeric","numeric","numeric",
                             "numeric","numeric","numeric","numeric"))
      #qualTable <- platform(qualTable)  ### Probably needs removal? - Calls platform function above to translate quality scores - DEPRICATED due to the potential for error
      qualTransl <- c(
                        q0 = "0% Quantile",
                        q10 = "10% Quantile",
                        q25 = "25% Quantile",
                        q50 = "50% Quantile",
                        q75 = "75% Quantile",
                        q90 = "90% Quantile",
                        q100 = "100% Quantile"
      )

      qualCols <- rainbow(ncol(qualTable[,quants2plot]))                                          # Assign a palette
      plot(NULL, xlim=c(1,nrow(qualTable)), ylim=c(min(qualTable)*0.9,max(qualTable)*1.1),
           xlab="Quality by Cycle", ylab="Quality",
           main = titleQ, cex.main = 1, cex.axis=0.7)
      matlines(as.matrix(qualTable[,quants2plot]), type="l", col = qualCols, lty=1,lwd =2,bty = "n")
      legend("bottomright", legend=qualTransl[colnames(qualTable[,quants2plot])],lty = 1, col=qualCols, 
           bty="n", lwd = 2, cex = 0.5, pt.cex = 0.5)
      
}

reaperBaseCompPlot <- function(inBaseFile, title){
   baseTable <- read.delim(inBaseFile, quote = "", row.names = 1, 
                           colClasses = c("character", "numeric", "numeric", "numeric" ,"numeric", "numeric"))
   #print("Here")
   baseTable <- baseTable[,c("A","T","G","C","N")]
   rowSum <- apply(baseTable,1,sum)
   baseTableFreqs <- as.data.frame(matrix(data = NA, nrow = nrow(baseTable), ncol = ncol(baseTable),
                            dimnames = list(row = rownames(baseTable), col = colnames(baseTable))))
   #print("No here")
   for(i in rownames(baseTable)){
      #print(paste("Rowname 1:",i,"Rowname 2:", rownames(baseTable[i,])))
      baseTableFreqs[i,] <- baseTable[i,]/rowSum[i]  # Convert base frequencies per cycle to base proportions
   }
   baseTableFreqs <- t(baseTableFreqs)
   baseTableFreqs <- baseTableFreqs[c("A","T","G","C","N"),]                                                # Assume these are the only bases we need to deal with - CHECK
   cols <- c("palegreen3","palevioletred3","palegoldenrod","paleturquoise3","grey")
   names(cols) <- rownames(baseTableFreqs)
   barplot(as.matrix(baseTableFreqs), ylim=c(0,1.1), col=cols, beside=FALSE, border="black", space=0, 
           xlab="Base frequency by Cycle", ylab="Frequency", las=3, cex.axis=0.7, cex.names=0.6,
           main=title, cex.main = 1, xaxt='n')
   abline(h=seq(0,1,0.2), lty=3, lwd=1, col="darkgrey")
   legend("top",legend=rownames(baseTableFreqs), fill=cols, bty="o", bg="white", horiz=TRUE,cex = 0.5, pt.cex = 0.5)
   axis(side=1,at=seq.int(0,ncol(baseTableFreqs),5),cex.axis= 0.7)
}

reaperLengthPlot <- function(lenFile, titleL){
   lenTable <- read.delim(lenFile, quote = "", row.names = 1, colClasses = c("character","numeric"))
   lenTable$millions <- lenTable$count/1000000
   ymaxLen = max(lenTable$millions)
   lenTable <- t(lenTable)
   barplot(lenTable["millions",], ylim = c(0,1.2*ymaxLen),las=3, 
            xlab="Read length following REAPER", main = titleL,
            ylab="Number of reads (millions)",col = "orange", border=NA,cex.axis=0.7,  cex.names=0.7, cex.main = 1)
   return(sum(lenTable)) ### Return value to allow comparison of total reads with each barcode
}
