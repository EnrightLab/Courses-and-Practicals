
#include "version.h"

const char reaper_tag[] = "reaper-12-130";
const char tally_tag[]  = "tally-12-130";
const char minion_tag[] = "minion-12-130";
const char swan_tag[]   = "swan-12-130";

