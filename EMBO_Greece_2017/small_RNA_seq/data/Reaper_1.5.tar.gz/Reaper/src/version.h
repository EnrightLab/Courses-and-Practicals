

#ifndef include_version
#define include_version

extern const char reaper_tag[];
extern const char tally_tag[];
extern const char minion_tag[];
extern const char swan_tag[];

#endif


