
/*
 * (C) Copyright 2011 2012 European Molecular Biology Laboratory.
 * Author: Stijn van Dongen <stijn@ebi.ac.uk>.
 * Contact: <kraken@ebi.ac.uk>
 *
 * This file is part of Reaper.   Reaper is free software: you can redistribute
 * it  and/or modify it under the terms of the  GNU  General  Public License as
 * published by the Free Software Foundation;  either version 3 of the License,
 * or  (at your option)  any later version.  This program is distributed in the
 * hope that it will be useful,  but  WITHOUT  ANY  WARRANTY;  without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the  GNU  General  Public  License  for  more  details.  You should have
 * received a copy of the  GNU  General Public License along with this program.
 * If not, see http://www.gnu.org/licenses/.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>
#include <sys/stat.h>

#include "slib.h"


int argv_i = 0, noargallowed = 0;
const char* argh_lead = "";

FILE* fpargh = NULL;


int set_argh(const char* fname, int die)
   {  FILE* fp = myfopen(fname, "a", 0)
   ;  if (!fp && die)
      exit(11)
   ;  if (fp)
      fpargh = fp
   ;  return fp ? 0 : 1
;  }


int close_argh()
   {  if (fpargh != stderr)
      fclose(fpargh)
;  }



int argh
(  const char* tag
,  const char* fmt
,  ...
)
   {  va_list  args
   ;  FILE* fp = fpargh
   ;  if (!fp)
      fp = stderr
   ;  va_start(args, fmt)
   ;  fprintf(fp, "%s[%s] ", argh_lead, tag)
   ;  vfprintf(fp, fmt, args)
   ;  fputc('\n', fp)
   ;  va_end(args)
   ;  return 29
;  }


int arrr
(  const char* fmt
,  ...
)
   {  va_list  args
   ;  FILE* fp = fpargh
   ;  if (!fp)
      fp = stderr
   ;  va_start(args, fmt)
   ;  vfprintf(fp, fmt, args)
   ;  fputc('\n', fp)
   ;  va_end(args)
   ;  return 29
;  }


void die
(  int e
,  const char* fmt
,  ...
)
   {  va_list  args
   ;  FILE* fp = fpargh
   ;  if (!fp)
      fp = stderr
   ;  va_start(args, fmt)
   ;  vfprintf(fp, fmt, args)
   ;  fputc('\n', fp)
   ;  va_end(args)
   ;  exit(e)
;  }


void* myrealloc(void* mem, size_t n)
   {  mem = realloc(mem, n)
   ;  if (!mem && n)
      {  arrr("cannae realloc %lu to bytes", (unsigned long) n)
      ;  exit(ENOMEM)
   ;  }
      return mem
;  }


char* stringle
(  const char* fmt
,  ...
)
   {  va_list  args
#define MAX_FILENAME_LENGTH 4095
   ;  char buf[MAX_FILENAME_LENGTH+1]
   ;  char* fn
   ;  int written

   ;  va_start(args, fmt)
   ;  written = vsnprintf(buf, MAX_FILENAME_LENGTH, fmt, args)
   ;  va_end(args)

   ;  if (written >= MAX_FILENAME_LENGTH || written < 0 || !(fn = malloc(written+1)))
         arrr("cannot construct full file name")
      ,  exit(1)
   ;  memcpy(fn, buf, written)
   ;  fn[written] = '\0'
   ;  return fn
;  }


void myfzclose(void* fpp, int zippit)
   {  if(fpp)
      {  int ret
#if WE_USE_ZLIB
      ;  gzflush(fpp, Z_FINISH)
      ;  ret = zippit ? gzclose(fpp) : fclose(fpp)
#else
      ;  ret = fclose(fpp)
#endif
   ;  if (ret)
      fprintf(stderr, "[slib] return code %d\n", (int) ret)
   ;  }
   }


void* myfopen (const char* fname, const char* mode, int z)
   {  FILE* fp = NULL
   ;  if (!strcmp(fname, "-"))
      {  if (strchr(mode, 'w'))
         fp = stdout
      ;  else if (strchr(mode, 'r'))
         fp = stdin
      ;  else
         arrr("fire: unrecognized open mode <%s>", mode)     /* fp now NULL */
   ;  }
      else if (!strcmp(fname, "stderr") && !strchr(mode, 'w'))
      fp = stderr
   ;  else
      {  fp = fopen(fname, mode)
      ;  if (!fp)
         arrr("cannae open file <%s> in mode <%s>", fname, mode)
   ;  }

#if WE_USE_ZLIB
      if (z && fp)
      {  int fn = fileno(fp)
      ;  if (fn < 0)
         arrr("bad fileno (file %s)", fname)
      ;  return fn < 0 ? NULL : gzdopen(fn, mode)
   ;  }
#endif
      return fp
;  }


void* myalloc(size_t n)
   {  return myrealloc(NULL, n)
;  }

#define RL_OK     0
#define RL_DONE   1
#define RL_ERROR  2
#define RL_NOMEM  4


int kraken_hookline
(  ZFILE ip
,  struct file_buffer* fb
,  char* dest
,  unsigned  dest_capacity
,  unsigned* dest_written
,  unsigned* truncated
)
   {  unsigned n_copied             =  0
   ;  int have_newline              =  0
   ;  int have_cr                   =  0
   ;  int n_add                     =  0
   ;  int n_added                   =  0

   ;  if (!dest)                    /* special initialiser invocation */
      {  fb->rl_ct = 0
      ;  fb->rl_offset = 0
      ;  fb->rl_available = 0
      ;  fb->rl_flush = 0
      ;  return RL_OK
   ;  }

      fb->rl_ct++
   ;  truncated[0] = 0

                           /* it's a slight blemish that below reads will be attempted
                            * while feof(ip) or gzeof(ip) is already true.
                            * Solution would be to keep track of eof() if reads return 0 bytes,
                            * or to restructure the code.
                           */
   ;  do
      {  const unsigned char* p
      ;  if (!fb->rl_available)
         {  fb->rl_offset = 0
         ;  do
            {
#if WE_USE_ZLIB
               fb->rl_available = gzread(ip, fb->rl_buf, RL_BUFSIZE)
#else
               fb->rl_available = fread(fb->rl_buf, 1, RL_BUFSIZE, ip)
#endif
            ;  if (fb->rl_flush && (p = memchr(fb->rl_buf, '\n', fb->rl_available)))
               {  fb->rl_offset = 1 + p - fb->rl_buf
               ;  fb->rl_available -= 1 + p - fb->rl_buf
               ;  fb->rl_flush = 0
            ;  }
            }
            while (fb->rl_flush && fb->rl_available)
      ;  }

         if (!fb->rl_available)
         return RL_DONE

      ;  if ((p = memchr(fb->rl_buf + fb->rl_offset, '\n', fb->rl_available)))
         {  have_newline = 1
         ;  if (p > fb->rl_buf && p[-1] == '\r')
            have_cr = 1
      ;  }
         else
         p = fb->rl_buf + fb->rl_offset + fb->rl_available

      ;  n_added = n_add = (p - fb->rl_buf) - fb->rl_offset

      ;  if (n_copied + n_added > dest_capacity)
         {  truncated[0] = 1
         ;  n_added = dest_capacity - n_copied        /* adjust number to copy */
      ;  }

         if (n_added > fb->rl_available)
         {  arrr("panic n_added=%d rl_available=%d", (int) n_added, (int) fb->rl_available)
         ;  return RL_ERROR
      ;  }

         memcpy(dest+n_copied, fb->rl_buf + fb->rl_offset, n_added)
#if 0
;dest[n_copied+n_added] = '\0'
;fprintf(stderr, "copy [%d] offset [%d] available [%d] line [%d] newline [%d / %d]\n"
, (int) n_added, (int) fb->rl_offset, (int) fb->rl_available, (int) fb->rl_ct, have_newline, (int) (p - fb->rl_buf))
#endif
      ;  n_copied     += n_added
      ;  fb->rl_offset    += n_added + have_newline
      ;  fb->rl_available -= n_added + have_newline
   ;  }
      while (n_added == n_add && !have_newline)

   ;  if (n_added < n_add)
      {  if (have_newline)                /* already found next offset */
            fb->rl_offset += n_add - n_added
         ,  fb->rl_available -= n_add - n_added
      ;  else                             /* this is the annoying case */
            fb->rl_flush = 1
         ,  fb->rl_offset = 0
         ,  fb->rl_available = 0
   ;  }

      if (have_cr)
      n_copied--

   ;  dest[n_copied] = '\0'               /* fixme document why this is safe */
   ;  dest_written[0] = n_copied
   ;  return RL_OK
;  }



   /* -  only allows lines of length up to dest_capacity
    * -  to reset static counters, invoke with kraken_readline(NULL, NULL, 0, 0)
   */

int kraken_readline
(  ZFILE ip
,  char* dest
,  unsigned  dest_capacity
,  unsigned* dest_written
,  unsigned* truncated
)
   {  static unsigned char rl_buf[RL_BUFSIZE]
   ;  static unsigned rl_offset     =  0
   ;  static int rl_available       =  0
   ;  static int rl_ct              =  0
   ;  static int rl_flush           =  0
   ;  static int rl_bufsize         =  RL_BUFSIZE

   ;  unsigned n_copied             =  0
   ;  int have_newline              =  0
   ;  int have_cr                   =  0
   ;  int n_add                     =  0
   ;  int n_added                   =  0

   ;  if (!ip && !dest)    /* special initialiser invocation */
      {  rl_ct = 0
      ;  rl_offset = 0
      ;  rl_available = 0
      ;  rl_flush = 0
      ;  return RL_OK
   ;  }

      rl_ct++
   ;  truncated[0] = 0

                           /* it's a slight blemish that below reads will be attempted
                            * while feof(ip) or gzeof(ip) is already true.
                            * Solution would be to keep track of eof() if reads return 0 bytes,
                            * or to restructure the code.
                           */
   ;  do
      {  const unsigned char* p
      ;  if (!rl_available)
         {  rl_offset = 0
         ;  do
            {
#if WE_USE_ZLIB
               rl_available = gzread(ip, rl_buf, rl_bufsize)
#else
               rl_available = fread(rl_buf, 1, rl_bufsize, ip)
#endif
            ;  if (rl_flush && (p = memchr(rl_buf, '\n', rl_available)))
               {  rl_offset = 1 + p - rl_buf
               ;  rl_available -= 1 + p - rl_buf
               ;  rl_flush = 0
            ;  }
            }
            while (rl_flush && rl_available)
      ;  }

         if (!rl_available)
         return RL_DONE

      ;  if ((p = memchr(rl_buf + rl_offset, '\n', rl_available)))
         {  have_newline = 1
         ;  if (p[-1] == '\r')
            have_cr = 1
      ;  }
         else
         p = rl_buf + rl_offset + rl_available

      ;  n_added = n_add = (p - rl_buf) - rl_offset

      ;  if (n_copied + n_added > dest_capacity)
         {  truncated[0] = 1
         ;  n_added = dest_capacity - n_copied        /* adjust number to copy */
      ;  }

         if (n_added > rl_available)
         {  arrr("panic n_added=%d rl_available=%d", (int) n_added, (int) rl_available)
         ;  return RL_ERROR
      ;  }

         memcpy(dest+n_copied, rl_buf + rl_offset, n_added)
#if 0
;dest[n_copied+n_added] = '\0'
;fprintf(stderr, "copy [%d] offset [%d] available [%d] line [%d] newline [%d / %d]\n"
, (int) n_added, (int) rl_offset, (int) rl_available, (int) rl_ct, have_newline, (int) (p - rl_buf))
#endif
      ;  n_copied     += n_added
      ;  rl_offset    += n_added + have_newline
      ;  rl_available -= n_added + have_newline
   ;  }
      while (n_added == n_add && !have_newline)

   ;  if (n_added < n_add)
      {  if (have_newline)                /* already found next offset */
            rl_offset += n_add - n_added
         ,  rl_available -= n_add - n_added
      ;  else                             /* this is the annoying case */
            rl_flush = 1
         ,  rl_offset = 0
         ,  rl_available = 0
   ;  }

      if (have_cr)
      n_copied--

   ;  dest[n_copied] = '\0'               /* fixme document why this is safe */
   ;  dest_written[0] = n_copied
   ;  return RL_OK
;  }


unsigned char* afileate
(  FILE* fp
,  unsigned long* sizep
)
   {  struct stat mystat
   ;  unsigned long n_data_alloc = 4096
   ;  unsigned long N = 0
   ;  long n = 0
   ;  unsigned char* d

   ;  if (fstat(fileno(fp), &mystat))
      fprintf(stderr,  "[afileate] cannae stat file\n")
   ;  else if (mystat.st_size > n_data_alloc)
      n_data_alloc = mystat.st_size + 1

   ;  d = malloc(n_data_alloc)

   ;  while ((n = fread(d+N, 1, 4096, fp)) > 0)
      {  if (N+n+1+4096 > n_data_alloc)     /* extra space to write '\0' at EOF */
         {  n_data_alloc *= 1.141
         ;  if (n_data_alloc < N+n+1+4096)
            n_data_alloc = N+n+1+10*4096
         ;  d = realloc(d, n_data_alloc)
      ;  }
         N += n
   ;  }
      sizep[0] = N
   ;  d[N] = '\0'
   ;  return d
;  }


