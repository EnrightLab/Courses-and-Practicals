
/*
 * (C) Copyright 2011 2012 European Molecular Biology Laboratory.
 * Author: Stijn van Dongen <stijn@ebi.ac.uk>.
 * Contact: <kraken@ebi.ac.uk>
 *
 * This file is part of Reaper.   Reaper is free software: you can redistribute
 * it  and/or modify it under the terms of the  GNU  General  Public License as
 * published by the Free Software Foundation;  either version 3 of the License,
 * or  (at your option)  any later version.  This program is distributed in the
 * hope that it will be useful,  but  WITHOUT  ANY  WARRANTY;  without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the  GNU  General  Public  License  for  more  details.  You should have
 * received a copy of the  GNU  General Public License along with this program.
 * If not, see http://www.gnu.org/licenses/.
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>

#include "sw.h"
#include "slib.h"


#if 0
int argv_i = 0, noargallowed = 0;
#define thearg()  (  noargallowed      \
                  ?  arrr              \
                     (  "programmer brain damage, do not use option %s"    \
                     ,  argv[argv_i]   \
                     )                 \
                     ,  "argument-not-available" : argv[argv_i]     \
                  )
#define arg_switch()          while (++argv_i < argc) { if (0) {}
#define incopt(f)             if (++argv_i >= argc) return arrr("option %s requires argument", f)
#define optarg(f)             else if (!strcmp(thearg(), f)) { incopt(f);
#define uniarg(f)             else if (!strcmp(thearg(), f)) { noargallowed = 1;
#define uniargs(f,g)          else if (!strcmp(thearg(), f) || !strcmp(thearg(), g)) { noargallowed = 1;
#define failarg()             else { return arrr("unrecognized option <%s>", thearg()); }
#define endarg()              noargallowed = 0; }
#define arg_done()            }


int arrr
(  const char* fmt
,  ...
)
   {  va_list  args
   ;  va_start(args, fmt)
   ;  vfprintf(stderr, fmt, args)
   ;  fputc('\n', stderr)
   ;  va_end(args)
   ;  return 14
;  }


void* myrealloc(void* mem, size_t n)
   {  mem = realloc(mem, n)
   ;  if (!mem && n)
      {  arrr("cannae realloc %lu to bytes", (unsigned long) n)
      ;  exit(ENOMEM)
   ;  }
      return mem
;  }


void myfzclose(FILE* fpp)
   {  if(fpp)
      {
         fclose(fpp)
   ;  }
   }


void* myfopen (const char* fname, const char* mode)
   {  FILE* fp = NULL
   ;  if (!strcmp(fname, "-"))
      {  if (!strcmp(mode, "w"))
         fp = stdout
      ;  else if (!strcmp(mode, "r"))
         fp = stdin
      ;  else
         arrr("fire: unrecognized open mode <%s>", mode)     /* fp now NULL */
   ;  }
      else if (!strcmp(fname, "stderr") && !strcmp(mode, "w"))
      fp = stderr
   ;  else
      {  fp = fopen(fname, mode)
      ;  if (!fp)
         arrr("cannae open file <%s> in mode <%s>", fname, mode)
   ;  }

      return fp
;  }
#endif


void sw_printaln5
(  struct sw_alninfo* ai
,  int accept
,  int score
,  void* fp
,  int zippit
,  int recno
)
   {  unsigned o = ai->aln_ofs
   ;  char space[512]
   ;  char buf[8192]
   ;  int n
   ;  int leftflush = ai->lft_start > ai->rgt_start
   ;  int shift = (int) ai->lft_start - (int) ai->rgt_start

   ;  memset(space, ' ', 512)
   ;  space[511] = '\0'

   ;  if (shift < 0)
      shift = -shift

   ;  n
   =  snprintf
      (  buf
      ,  8192
      ,  "%.*s%.*s%s%s : [%d,%d]\n%.*s%.*s%s : score %d\n%.*s%.*s%s%s : [%d,%d] %d/%d recno=%d\n.\n"
       /* 1 1 1 1 1 1     2  2    3 3 3 3 3          3   4 4 4 4 4 4    5  5   6  6      7 */
/* 1 */
      ,  leftflush ? 0 : shift         /* this much */
      ,  space
      ,  (int) (ai->lft_start-1)       /* this much */
      ,  ai->left
      ,  ai->aln_lft+o
      ,  ai->left + (ai->lft_end)
/* 2 */
      ,  (int) ai->lft_start
      ,  (int) ai->lft_end
/* 3 */
      ,  shift
      ,  space
      ,  (int) ((leftflush ? ai->rgt_start : ai->lft_start) - 1)
      ,  space
      ,  ai->aln_aln+o
      ,  (int) ai->data[ai->max_ij]
/* 4 */
      ,  leftflush ? shift : 0
      ,  space
      ,  (int) (ai->rgt_start -1)
      ,  ai->right
      ,  ai->aln_rgt+o
      ,  ai->right + (ai->rgt_end)
/* 5 */
      ,  (int) ai->rgt_start
      ,  (int) ai->rgt_end
/* 6 */
      ,  (int) accept
      ,  (int) score
/* 7 */
      ,  (int) recno
      )
#if WE_USE_ZLIB
   ;  if (n > 0)
      {
         if (zippit) gzwrite(fp, buf, n)
      ;  else        fputs(buf, fp)
#else
         fputs(buf, fp)
#endif
   ;  }
   }



int main
(  int argc
,  char* argv[]
)
   {  FILE* fpo = stdout
#define BUFSIZE 4096
   ;  const char* g_fnout = "-"

#define MATRIX_SIZE 8192
   ;  SWNUM data[MATRIX_SIZE] = { 0 }
   ;  struct sw_alninfo ai = { 0 }
   ;  struct sw_param swp = { 0 }
   ;  int indel_allowed = 1
   ;  int dump_matrix = 0
   ;  int cell = 0

   ;  const char* trace = "n"

   ;  const char* left = "TCGTATGCCGTCTTCTGCTTGT", *right = "AAAAAATCGTATGCCGTCTTCTGCTTGAAAAAAAAT"

   ;  swp.cost_gapleft      =  1
   ;  swp.cost_gapright     =  1
   ;  swp.cost_subst        =  1
   ;  swp.gain_match        =  2
   ;  swp.left_skip         =  0
   ;  swp.right_limit       =  0
   ;  swp.flags             =  0

/* enter macromagical option world */
      
   ;  arg_switch()

      uniarg("-h")
puts("-o                output file name (STDOUT)");
puts("-l DNA-string     string to align");
puts("-r DNA-string     string to align");
puts("-swp M/S/G        match/substitution/gap gain/cost/cost");
puts("-lsrl L/R         left skip / right limit");
puts("-trace [olr]+     o: use old code  l: trim left r: trim right");   
puts("--noindel         do not consider indels while aligning");
puts("--matrix          dump alignment matrix");
puts("-cell <int>       align from cell <int>");
exit(0);
      endarg()

      optarg("-o")  g_fnout = thearg(); endarg()
      optarg("-trace") trace = thearg(); endarg()
      optarg("-cell") cell = atoi(thearg()); endarg()
      optarg("-swp")
         if
         (  3 != sscanf(thearg(), "%u/%u/%u", &swp.gain_match, &swp.cost_subst, &swp.cost_gapleft)
         )
         die(1, "-swp requires %%u/%%u/%%u format");
         swp.cost_gapright = swp.cost_gapleft;
      endarg()
      optarg("-lsrl")
         if
         (  2 != sscanf(thearg(), "%u/%u", &swp.left_skip, &swp.right_limit)
         )
         die(1, "-lsrl requires %%u/%%u format");
      endarg()
      uniarg("--noindel") indel_allowed = 0; endarg()
      uniarg("--matrix") dump_matrix = 1; endarg()
      optarg("-l")  left  = thearg();  endarg()
      optarg("-r")  right = thearg();  endarg()
      failarg()
      arg_done()

/* exit macromagicalitaciousness */

   ;  if (!(fpo = myfopen(g_fnout, "w", 0)))
      exit(1)

   ;  if (sw_fill2(&ai, data, MATRIX_SIZE, left, right, swp.cost_gapleft + swp.cost_gapright, &swp))
      exit(1)

   ;  if (dump_matrix)
      sw_dump(&ai)

   ;  if (strchr(trace, 'o'))
      sw_trace2(&ai, &swp, indel_allowed, cell > 0 ? cell : ai.max_ij)
   ;  else
      sw_trace2a
      (  &ai
      ,  &swp
      ,  cell > 0 ? cell : ai.max_ij
      ,     (strchr(trace, 'l') ? SW_TRIMLEFT : 0)
         |  (strchr(trace, 'r') ? SW_TRIMRIGHT : 0)
      )

#if 0
   ;  sw_pp(&ai, 0, 0, fpo, 0, 1)
#else
   ;  sw_printaln5(&ai, 0, 0, fpo, 0, 1)
#endif

   ;  fclose(fpo)
   ;  return 0
;  }

/* dummy change */
