
/*
 * (C) Copyright 2011 2012 European Molecular Biology Laboratory.
 * Author: Stijn van Dongen <stijn@ebi.ac.uk>.
 * Contact: <kraken@ebi.ac.uk>
 *
 * This file is part of Reaper.   Reaper is free software: you can redistribute
 * it  and/or modify it under the terms of the  GNU  General  Public License as
 * published by the Free Software Foundation;  either version 3 of the License,
 * or  (at your option)  any later version.  This program is distributed in the
 * hope that it will be useful,  but  WITHOUT  ANY  WARRANTY;  without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the  GNU  General  Public  License  for  more  details.  You should have
 * received a copy of the  GNU  General Public License along with this program.
 * If not, see http://www.gnu.org/licenses/.
*/


#ifndef  include_sw
#define  include_sw

#include <stdio.h>
#include <stdlib.h>
#include <string.h>


/* CAVEAT:
   Caller supports missing q (and the q we get might be garbage, although
   certain to be in array positions that exist but could have 0 bytes etc),
   but we don't check this. It's callers responsibility.
*/


/* the alignment matrix is layed out as follows,

                x    0  1  2  .. .. ..  nj-1 ("right")
                  +----^--^--^--------^---
               0  |  0  0  0  0  ..  0  0
               1  |  0  .  .. .. .. .. ..
               2  |  0  :  .           ..
               :  |  0  :     .        ..
               :  |  0  :        .     ..
               :  |  0  :           .  ..
   ("left")  ni-1 |  0  .  .. .. .. .. ..

      nj == strlen(right) + 1
      ni == strlen(left) + 1

   In memory this is a concatenation of rows.  The first row and column are set
   to all-zero.  sometimes we use elem(ai, i, j) (in sw.c), but other times we
   use ai->data[ij] and compute dependent i and j as

      i = ij / ai->nj
      j = ij - (i * ai->nj)

   Fixme:
      document left_skip and right_limit
*/

                  /* defining SWNUM as double will allow longer alignments,
                   * but it is approximately twice as slow.
                  */
#if 1
#define SWNUM unsigned char
#else
#define SWNUM double
#endif

struct sw_alninfo
{  unsigned lft_start   /* NOTE this is in alignment space: first char corresponds to position 1 */
;  unsigned lft_end     /* NOTE inclusive */
;  unsigned rgt_start   /* NOTE this is in alignment space: first char corresponds to position 1 */
;  unsigned rgt_end     /* NOTE inclusive */
;  unsigned n_match
;  unsigned n_subst
;  unsigned n_insl
;  unsigned n_insr
;  SWNUM* data
;  const char* left
;  const char* right
;  const char* q
;  unsigned ni
;  unsigned nj
;  unsigned max_ij       /* i in left, j in right with max value in matrix */
;  unsigned max_ej       /* i is last in left, j somewhere in right with max value in row e(nd) */
#define SW_ALN_MAXSIZE 255
;  unsigned char aln_lft[SW_ALN_MAXSIZE+1]
;  unsigned char aln_aln[SW_ALN_MAXSIZE+1]
;  unsigned char aln_rgt[SW_ALN_MAXSIZE+1]
;  unsigned aln_ofs      /* start of alignment, inclusive */
;  unsigned aln_end      /* end of alignment, exclusive */
;  unsigned n_cells_used
;
}  ;


#define SW_VERBOSE      1 <<  0
#define SW_ENDTOSTART   1 <<  1
#define SW_INDELALLOWED 1 <<  2
#define SW_TRIMLEFT     1 <<  3
#define SW_TRIMRIGHT    1 <<  4
#define SW_TRIM         (SW_TRIMLEFT | SW_TRIMRIGHT)


struct sw_param
{  int cost_gapleft
;  int cost_gapright
;  int gain_match
;  int cost_subst
;  unsigned left_skip
;  unsigned right_limit
;  unsigned flags
;
}  ;


unsigned sw_fit
(  struct sw_alninfo* ai
,  unsigned ij
)  ;


int sw_fill2
(  struct sw_alninfo* ai
,  SWNUM* data
,  unsigned data_size
,  const char *left           /* fixme, length-encode */
,  const char *right          /* fixme, length-encode */
,  int indel_allowed
,  struct sw_param* swp
)  ;


void sw_trace2
(  struct sw_alninfo* ai
,  struct sw_param* swp
,  int indel_allowed
,  unsigned ij
)  ;


void sw_trace2a
(  struct sw_alninfo* ai
,  struct sw_param* swp
,  unsigned ij
,  unsigned modes
)  ;


void sw_trace3
(  struct sw_alninfo* ai
,  struct sw_param* swp
,  unsigned ij
,  unsigned modes
)  ;


void sw_printaln
(  struct sw_alninfo* ai
,  FILE* out
)  ;

void sw_pp
(  struct sw_alninfo* ai
,  int accept
,  int score
,  FILE* fp
,  int zippit
,  int recno
)  ;

void sw_dump
(  struct sw_alninfo* ai
)  ;


               /* not yet used in sw.c, but this is probably the best place for future developments */
struct match_requirement
{  unsigned mr_minlen
;  unsigned mr_maxedit
;  unsigned mr_maxgap
;  int mr_offset
;
}  ;

#endif

