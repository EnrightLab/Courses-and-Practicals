
/*
 * (C) Copyright 2011 2012 European Molecular Biology Laboratory.
 * Author: Stijn van Dongen <stijn@ebi.ac.uk>.
 * Contact: <kraken@ebi.ac.uk>
 *
 * This file is part of Reaper.   Reaper is free software: you can redistribute
 * it  and/or modify it under the terms of the  GNU  General  Public License as
 * published by the Free Software Foundation;  either version 3 of the License,
 * or  (at your option)  any later version.  This program is distributed in the
 * hope that it will be useful,  but  WITHOUT  ANY  WARRANTY;  without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the  GNU  General  Public  License  for  more  details.  You should have
 * received a copy of the  GNU  General Public License along with this program.
 * If not, see http://www.gnu.org/licenses/.
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "sw.h"
#include "slib.h"

#define elem(ai,i,j)  ai->data[((i) * ai->nj) + (j)]


/* data is layed out as follows,

                x    0  1  2  .. .. ..  nj-1
                  +----^--^--^--------^---
               0  |  0  0  0  0  ..  0  0
               1  |  0  .  .. .. .. .. ..
               2  |  0  :  .           ..
               :  |  0  :     .        ..
               :  |  0  :        .     ..
               :  |  0  :           .  ..
             ni-1 |  0  .  .. .. .. .. ..

      nj == strlen(right) + 1
      ni == strlen(left) + 1

   In memory this is a concatenation of rows.  The first row and column are set
   to all-zero.  sometimes we use elem(ai, i, j), but other times we use
   ai->data[ij] and compute dependent i and j as

      i = ij / ai->nj
      j = ij - (i * ai->nj)
*/

unsigned sw_fit
(  struct sw_alninfo* ai
,  unsigned ij
)
   {  unsigned i = ij / ai->nj
   ;  unsigned j = ij - (i * ai->nj)
   ;  unsigned ret = ij
   ;  if (j && elem(ai, i, j-1) == elem(ai, i, j))
      ret = ij - 1
   ;  if (i && elem(ai, i-1, j) == elem(ai, i, j))
      ret = ij - ai->nj
;fprintf(stderr, "ij %d ret %d\n", (int) ij, (int) ret)
   ;  return ret
;  }


int sw_fill2
(  struct sw_alninfo* ai
,  SWNUM* data
,  unsigned data_size
,  const char *left           /* fixme, length-encode */
,  const char *right          /* fixme, length-encode */
,  int indel_allowed
,  struct sw_param* swp
)
   {  int i, j
   ;  const int COST_GAPLEFT = swp->cost_gapleft
   ;  const int COST_GAPRIGHT = swp->cost_gapright
   ;  const int COST_SUBST = swp->cost_subst
   ;  const int GAIN_MATCH = swp->gain_match
   ;  const unsigned left_skip = swp->left_skip
   ;  const unsigned right_limit = swp->right_limit
   ;  unsigned flags = swp->flags
   ;  memset(ai, 0, sizeof ai)
   ;  ai->data = data
   ;  ai->left = left
   ;  ai->right = right
   ;  ai->ni   = strlen(left) + 1
   ;  ai->nj   = strlen(right) + 1
   ;  unsigned mm = 0, ij = 0
   ;  unsigned e = ai->ni-1, mme = 0, ej = 0     /* at end of left string */
   ;  unsigned lowerleft = flags & SW_ENDTOSTART

   ;  if (indel_allowed)
      swp->flags |= SW_INDELALLOWED

   ;  if ( ai->ni * ai->nj > data_size )
      {  fprintf(stderr, "sw matrix size does not fit in data segment\n")
      ;  return 1
   ;  }

      memset(data, 0, ai->nj * sizeof data[0])
   ;  ai->n_cells_used = 0

#define MAX_ABS_DELTA 4
#if 0
#define GAIN_MATCH  2
#define COST_GAP    1
#define COST_SUBST  1
#endif

   ;  for (i=left_skip+1;i<ai->ni;i++)
      {  unsigned maxj = ai->nj
      ;  if (lowerleft && i+1 < maxj)
         maxj = i + 1
      ;  if (right_limit && right_limit+1 < maxj)
         maxj = right_limit + 1
         
      ;  ai->n_cells_used += maxj

      ;  elem(ai, i, 0) = 0

      ;  for (j=1;j<maxj;j++)
         {  unsigned char l = left[i-1]
         ;  unsigned char r = right[j-1]
         ;  unsigned match  = l != r || l == 'N' || r == 'N' ?  0 : 1
         ;  int newval = GAIN_MATCH * match            /* assuming match starts here */
         ;  int iidelta = match ? GAIN_MATCH : -COST_SUBST
         ;  elem(ai,i,j) = 0

         ;  if (indel_allowed)
            {  if (elem(ai, i, j-1) > newval + COST_GAPLEFT)   /* step right; gap in left */
               newval = elem(ai, i, j-1) - COST_GAPLEFT
            ;  if (elem(ai, i-1, j) > newval + COST_GAPRIGHT)  /* step left; gap in right */
               newval = elem(ai, i-1, j) - COST_GAPRIGHT
         ;  }
            if (elem(ai, i-1, j-1) + (MAX_ABS_DELTA + iidelta) > (MAX_ABS_DELTA + newval))
            newval = elem(ai, i-1, j-1) + iidelta
         ;  if (newval >= 0)
            elem(ai, i, j) = newval
         ;  if (elem(ai,i,j) > mm)
               ij = i * ai->nj + j
            ,  mm = elem(ai,i,j)
      ;  }
      }
      for (j=0;j<ai->nj;j++)
      {  if (elem(ai, e, j) > mme)
            ej = e * ai->nj + j
         ,  mme = elem(ai, e, j)
   ;  }
      ai->max_ij = ij   /* sw_fit(ai, ij) */
   ;  ai->max_ej = ej   /* sw_fit(ai, ej) */
   ;  return 0
;  }


void sw_dump
(  struct sw_alninfo* ai
)
   {  int i, j

   ;  for (i=0;i<ai->ni;i++)
      {  fprintf(stdout, "%3d %c: ", i, i ? (int) ai->left[i-1] : '-')
      ;  for (j=0;j<ai->nj;j++)
         fprintf(stdout, "%3d", (int) elem(ai,i,j))
      ;  fprintf(stdout, "  : %d\n", (int) ((i+1) * ai->nj - 1))
   ;  }

   ;  fputs("\n  - -    -", stdout)
   ;  for (i=1;i<ai->nj;i++)
      fprintf(stdout, "%3c", (int) ai->right[i-1])
   ;  fputc('\n', stdout)

   ;  fputs("  - -    -", stdout)
   ;  for (i=1;i<ai->nj;i++)
      fprintf(stdout, "%3d", i)
   ;  fprintf(stdout, "\n   max cell %d value %d\n", ji ai->max_ij, ji ai->data[ai->max_ij])
   ;  fprintf(stdout, "   max last-row cell %d value %d\n", ji ai->max_ej, ji ai->data[ai->max_ej])
;  }


void sw_trace2a
(  struct sw_alninfo* ai
,  struct sw_param* swp
,  unsigned ij
,  unsigned modes
)
   {  unsigned i = ij / ai->nj
   ;  unsigned j = ij - (i * ai->nj)
   ;  unsigned nj = ai->nj
   ;  SWNUM* data = ai->data
   ;  unsigned n_subst = 0
   ;  unsigned n_match = 0
   ;  unsigned n_insl = 0
   ;  unsigned n_insr = 0
   ;  int indel_allowed = swp->flags & SW_INDELALLOWED

   ;  ai->lft_end = i
   ;  ai->rgt_end = j

   ;  int o_start = SW_ALN_MAXSIZE

   ;  if (ij)
      do
      {  unsigned new11 = ij-nj-1            /* diagonal step          */
      ;  unsigned new10 = ij-1               /* step left; gap in left */
      ;  unsigned new01 = ij-nj              /* step right: gap in right */
      ;  unsigned newij = new11
      ;  unsigned char theleft  = ai->left[i-1]
      ;  unsigned char theright = ai->right[j-1]
      ;  unsigned char status = theleft == 'N' || theright == 'N' ? 'x' : '|'

      ;  if (data[ij] <= 0 || --o_start < 0)
         break

      ;  ai->aln_lft[o_start] = ai->left[i-1]
      ;  ai->aln_rgt[o_start] = ai->right[j-1]

      ;  if (theleft == theright)
         newij = new11
                                             /* prefer match always */
      ;  else if (!indel_allowed || data[new11] > data[ij])     /* substitution */
            status = 'x'
         ,  newij = new11
      ;  else if (indel_allowed && (data[new10] > data[ij]))    /* gap in left  */
            status = 'l'
         ,  ai->aln_lft[o_start] = '-'
         ,  newij = new10
      ;  else if (indel_allowed && data[new01] > data[ij])      /* gap in right  */
            status = 'r'
         ,  ai->aln_rgt[o_start] = '-'
         ,  newij = new01

      ;  ai->aln_aln[o_start] = status

      ;  ij = newij
      ;  i = ij / ai->nj
      ;  j = ij - (i * ai->nj)
;if(0)fprintf(stderr, "\n} %s {\n} %s {\n} %s [%c]{\n", ai->aln_rgt+o_start, ai->aln_aln+o_start, ai->aln_rgt+o_start, (int) ai->aln_rgt[SW_ALN_MAXSIZE])
;if (swp->flags & SW_VERBOSE)
fprintf
(   stderr
,   "i %d j %d status %c val %d\n"
,   (int) i
,   (int) j
,   (int) status
,   (int) data[newij]
)
   ;  }
      while (ij && data[ij] > 0)

   ;  {  int o_right = SW_ALN_MAXSIZE              /* EXCLUSIVE */
      ;  int o_left  = o_start                     /* inclusive */
      ;  int n_left_trim_lr = 0
      ;  int n_left_trim_r = 0
      ;  int n_left_trim_l = 0
      ;  int o

      ;  if (modes & SW_TRIMRIGHT)
         {  int trimscore = 0
         ;  for (o = SW_ALN_MAXSIZE-1; o > o_start; o--)
            {  trimscore += ai->aln_aln[o] == '|' ? 1 : -1
            ;  if (trimscore <= 0 && ai->aln_aln[o] != '|')
               o_right = o
         ;  }
         }

         if (modes & SW_TRIMLEFT)
         {  int trimscore = 0
         ;  for (o = o_start; o < o_right; o++)
            {  trimscore += ai->aln_aln[o] == '|' ? 1 : -1
            ;  if (trimscore <= 0 && ai->aln_aln[o] != '|')
               o_left = o+1
         ;  }
         }

         ai->aln_lft[o_right] = '\0'
      ;  ai->aln_aln[o_right] = '\0'
      ;  ai->aln_rgt[o_right] = '\0'

      ;  for (o=o_start;o<o_left;o++)
         {  switch((unsigned char) ai->aln_aln[o])
            {  case '|' : n_left_trim_lr++; break
            ;  case 'x' : n_left_trim_lr++; break
            ;  case 'l' : n_left_trim_r++; break
            ;  case 'r' : n_left_trim_l++; break
         ;  }
         }

      ;  for (o=o_left;o<o_right;o++)
         {  switch((unsigned char) ai->aln_aln[o])
            {  case '|' : n_match++; break
            ;  case 'x' : n_subst++; break
            ;  case 'l' : n_insl++; ai->aln_aln[o] = '-'; break
            ;  case 'r' : n_insr++; ai->aln_aln[o] = '-'; break
         ;  }
         }

         ai->aln_ofs = o_left
      ;  ai->aln_end = o_right
      ;  ai->n_match = n_match
      ;  ai->n_subst = n_subst
      ;  ai->n_insl  = n_insl
      ;  ai->n_insr  = n_insr

      ;  ai->lft_start =  ( 1 + ij / ai->nj )  + n_left_trim_lr + n_left_trim_l
      ;  ai->rgt_start =  ( 1 + ij - ((ij / ai->nj) * ai->nj) )  + n_left_trim_lr + n_left_trim_r
      ;  ai->lft_end   =  ai->lft_start + ai->n_match + ai->n_subst + ai->n_insr -1
      ;  ai->rgt_end   =  ai->rgt_start + ai->n_match + ai->n_subst + ai->n_insl -1
   ;  }

;if(0)fprintf(stderr, "\n! %s {\n} %s {\n} %s [%c]{\n", ai->aln_rgt+o_start, ai->aln_aln+o_start, ai->aln_rgt+o_start, (int) ai->aln_rgt[SW_ALN_MAXSIZE])

;if(0)fprintf(stderr, "match %d gl %d gr %d sub %d ofs %d [%s] [%s]\n"
,(int) ai->n_match
,(int) ai->n_insl
,(int) ai->n_insr
,(int) ai->n_subst
,(int) ai->aln_ofs
, ai->left, ai->right
)
;  }


void sw_trace2
(  struct sw_alninfo* ai
,  struct sw_param* swp
,  int indel_allowed
,  unsigned ij
)
   {  unsigned i = ij / ai->nj
   ;  unsigned j = ij - (i * ai->nj)
   ;  unsigned nj = ai->nj
   ;  SWNUM* data = ai->data
   ;  unsigned n_subst = 0
   ;  unsigned n_match = 0
   ;  unsigned n_insl = 0
   ;  unsigned n_insr = 0

   ;  ai->lft_end = i
   ;  ai->rgt_end = j

   ;  int o = SW_ALN_MAXSIZE

   ;  ai->aln_lft[o] = '\0'
   ;  ai->aln_aln[o] = '\0'
   ;  ai->aln_rgt[o] = '\0'

   ;  if (ij)
      do
      {  unsigned new11 = ij-nj-1            /* diagonal step          */
      ;  unsigned new10 = ij-1               /* step left; gap in left */
      ;  unsigned new01 = ij-nj              /* step right: gap in right */
      ;  unsigned newij = new11
      ;  unsigned char status = 'm'

      ;  if (--o < 0)                        /* fixme: design such that this is unnecessary */
         break

      ;  ai->aln_lft[o] = ai->left[i-1]
      ;  ai->aln_rgt[o] = ai->right[j-1]

      ;  if (data[new11] > data[ij])         /* substitution */
            status = 's'
         ,  newij = new11
      ;  else if (indel_allowed && (data[new10] > data[ij]))    /* gap in left  */
            status = 'l'
         ,  ai->aln_lft[o] = '-'
         ,  newij = new10
      ;  else if (indel_allowed && data[new01] > data[ij])      /* gap in right  */
            status = 'r'
         ,  ai->aln_rgt[o] = '-'
         ,  newij = new01

      ;  ai->aln_aln[o] = status == 'm' ? '|' : status == 's' ? 'x' : '-'

      ;  switch(status)
         {  case 'm' : n_match++; break
         ;  case 's' : n_subst++; break
         ;  case 'l' : n_insl++; break
         ;  case 'r' : n_insr++; break
      ;  }

         ij = newij
      ;  i = ij / ai->nj
      ;  j = ij - (i * ai->nj)
;if(0)fprintf(stderr, "\n} %s {\n} %s {\n} %s [%c]{\n", ai->aln_rgt+o, ai->aln_aln+o, ai->aln_rgt+o, (int) ai->aln_rgt[SW_ALN_MAXSIZE])
;if (swp->flags & SW_VERBOSE)
fprintf
(   stderr
,   "i %d j %d status %c val %d\n"
,   (int) i
,   (int) j
,   (int) status
,   (int) data[newij]
)
   ;  }
      while (ij && data[ij] > 0)
;if(0)fprintf(stderr, "\n! %s {\n} %s {\n} %s [%c]{\n", ai->aln_rgt+o, ai->aln_aln+o, ai->aln_rgt+o, (int) ai->aln_rgt[SW_ALN_MAXSIZE])
   ;  ai->aln_ofs = o
   ;  ai->aln_end = SW_ALN_MAXSIZE
   ;  ai->n_match = n_match
   ;  ai->n_subst = n_subst
   ;  ai->n_insl  = n_insl
   ;  ai->n_insr  = n_insr
   ;  ai->lft_start =  1 + ij / ai->nj
   ;  ai->rgt_start =  1 + ij - (ij / ai->nj * ai->nj)
;  }


void sw_printaln
(  struct sw_alninfo* ai
,  FILE* out
)
   {  unsigned o = ai->aln_ofs
   ;  fprintf(out, "%s :\n%s :\n%s :\n", ai->aln_lft+o, ai->aln_aln+o, ai->aln_rgt+o)
;  }


void sw_pp
(  struct sw_alninfo* ai
,  int accept
,  int score
,  FILE* fp
,  int zippit
,  int recno
)
   {  unsigned o = ai->aln_ofs
   ;  char *space = "                                                                                "
   ;  char buf[8192]
   ;  int n
   ;  int leftflush = ai->lft_start > ai->rgt_start
   ;  int shift = (int) ai->lft_start - (int) ai->rgt_start

   ;  if (shift < 0)
      shift = -shift

   ;  n
   =  snprintf
      (  buf
      ,  8192
      ,  "%.*s%.*s%s%s : [%d,%d]\n%.*s%.*s%s : score %d\n%.*s%.*s%s%s : [%d,%d] %d/%d recno=%d\n.\n"
       /* 1 1 1 1 1 1     2  2    3 3 3 3 3          3   4 4 4 4 4 4    5  5   6  6      7 */
/* 1 */
      ,  leftflush ? 0 : shift         /* this much */
      ,  space
      ,  (int) (ai->lft_start-1)       /* this much */
      ,  ai->left
      ,  ai->aln_lft+o
      ,  ai->left + (ai->lft_end) /* mq */
/* 2 */
      ,  (int) ai->lft_start
      ,  (int) ai->lft_end
/* 3 */
      ,  shift
      ,  space
      ,  (int) ((leftflush ? ai->rgt_start : ai->lft_start) - 1)
      ,  space
      ,  ai->aln_aln+o
      ,  (int) ai->data[ai->max_ij]
/* 4 */
      ,  leftflush ? shift : 0
      ,  space
      ,  (int) (ai->rgt_start -1)
      ,  ai->right
      ,  ai->aln_rgt+o
      ,  ai->right + (ai->rgt_end) /* mq */
/* 5 */
      ,  (int) ai->rgt_start
      ,  (int) ai->rgt_end
/* 6 */
      ,  (int) accept
      ,  (int) score
/* 7 */
      ,  (int) recno
      )
   ;  if (n > 0)
      fputs(buf, fp)

   ;  fprintf(fp, "%s\n%s\n%s\n", ai->aln_lft+o, ai->aln_aln+o, ai->aln_rgt+o)
;  }


void sw_trace3
(  struct sw_alninfo* ai
,  struct sw_param* swp
,  unsigned ij
,  unsigned modes
)
   {  return
         0
      ?  sw_trace2(ai, swp, swp->flags & SW_INDELALLOWED , ij)
      :  sw_trace2a(ai, swp, ij, modes)
;  }


