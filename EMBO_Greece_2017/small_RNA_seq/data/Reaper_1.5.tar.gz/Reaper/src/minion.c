
/*
 * (C) Copyright 2011 2012 European Molecular Biology Laboratory.
 * Author: Stijn van Dongen <stijn@ebi.ac.uk>.
 * Contact: <kraken@ebi.ac.uk>
 *
 * This file is part of Reaper.   Reaper is free software: you can redistribute
 * it  and/or modify it under the terms of the  GNU  General  Public License as
 * published by the Free Software Foundation;  either version 3 of the License,
 * or  (at your option)  any later version.  This program is distributed in the
 * hope that it will be useful,  but  WITHOUT  ANY  WARRANTY;  without even the
 * implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the  GNU  General  Public  License  for  more  details.  You should have
 * received a copy of the  GNU  General Public License along with this program.
 * If not, see http://www.gnu.org/licenses/.
*/


#ifndef DEBUG_ON
#define DEBUG_ON 1
#endif


#if 0
#define KMER_DEBUG 43363288
#endif



/* TODO


-  how to accept junctions?  what are spurious edges? while respecting isoforms?

-  junctions near sources or sinks might be suspect.


u  retest on cycles. unititest ......
u  unit test on x junction.

*  enable dumping and reading of DB graph (machine format).
*  is k-1 graph derivable from k graph?
*  tie reads to paths

!  is the current approach order independent?

-  skip comments

-  note: drop-off only checked in one direction
   (note, we start from high-incident kmers, but still).

-  future feature:
      check suffix/prefix match. how to do efficiently?

-  if we discard an edge because of io_ratio disparity,
   what to do with the cut-off part? Introduce a source?

NOTE
   the absence of a plain occurrence count makes code awkward in places,
   and has led to surprising behaviour, almost bugs.
   Still understandable though, the edge is more important than the node.

-  equip consider_shift3 with ordering by frequency.

-  number of ccannot allocated is probably a bit much.

-  optify N_TRACK_CCANNOT

-  is prefix code (::) still being activated?

!  go back and test cycles.

-  supplying imin and omin as 0 on command line gives corruptish -d output.
-  how is AAAA (all-A kmer) prevented from being counted?

-  -do option
-  introduce struct param

-  detect/warn loops in graph search
   (research using 4-mers and ACCGCGTGACTGACTGACTGGTACGACCT)

-  annotate sequences with average depth;

-  depth-representation using a-yA-Y (representing percentage of greatest depth).

-  when sorting or heaping, skip anything with counts below io_omin

-  when heaping, count nr of things inserted in heap (!= 0).

-  connected component summary statistics.

-  detect/count junctions in lattice; T-junction clear; what about X-junctions?
   what about bbbPbPbbbbb (base polymorphism)?

-  how reliable are long transcripts?





criterion for accepting a link in connected component search.

x   -G +A   z

#x(-G) / #x(-*)   and  #z(+A) / #z(+*)

should both be sizable.

     ....... A
     ....... C
     ....... T
   A .......
     ....... G
   C .......
   G .......
   T .......






-  sort out heap selection; no longer power-of-2 based.

   when getting ws, make sure only nonzero counts are selected.
   (important; e.g. low complexity words have counts set to zero).

   -  keep stack of k-mers so far. Makes it easier to get accurate end count, for one thing
      -- it is now often obfuscated by the adapter start.

   -  make a type for kmer; enable 64 bits. some care required.

   -  parameterise magic cutoffs.
         in_out_ratio
         unrepeatiness
*/

#include "version.h"
#include "trint.h"
#include "slib.h"

#include <math.h>
#include <stdio.h>
#include <ctype.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
#include <stdarg.h>
#include <errno.h>


#if 0
#define BASEMAP(b)   (b == 'A' ? 0 : b == 'C' ? 1 : b == 'G' ? 2 : b == 'T' ? 3 : 4)
#else
#define BASEMAP(b)   themap[b]
#endif
                              /* A C G T are set in main() */
unsigned themap[256] =
   {5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   ,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   ,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   ,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   ,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   ,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   ,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   ,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5,5
   };

char dna[4] = { 'A', 'C', 'G', 'T' };


typedef long unsigned kun;         /* k-mer unsigned */
typedef unsigned ctr;         /* counter */
#define lu (long unsigned)
#define ju (unsigned)         /* just unsigned */
#define ji (int)              /* just int */


unsigned hash_sequence
(  char* s
,  unsigned length
)
   {  unsigned i, h=0
   ;  for (i=0;i<length;i++)
      h = 0 + ((h << 6) ^ (h << 21) ^ (h >> 13) ^ (s[i] * 71523))
   ;  return h >> 6
;  }


struct kmer
{  kun kmer
;  ctr ttr[4]                /* counts of the four possible kmers 'to the right' */
;  ctr nout                  /* sum of ttr. */
;  ctr nin                   /* sum of incoming edges */
;  int heap_offset
;
}  ;



#define X_LEFT_A    ( 1 <<  0 )
#define X_LEFT_C    ( 1 <<  1 )
#define X_LEFT_G    ( 1 <<  2 )
#define X_LEFT_T    ( 1 <<  3 )

#define X_RIGHT_A   ( 1 <<  4 )
#define X_RIGHT_C   ( 1 <<  5 )
#define X_RIGHT_G   ( 1 <<  6 )
#define X_RIGHT_T   ( 1 <<  7 )

#define X_LEFTRIGHT ((1 <<  8 ) -1)
#define X_LEFT_STAR ((1 <<  4 ) -1)
#define X_RIGHT_STAR (X_LEFT_STAR << 4)

#define X_SEEN      ( 1 <<  8 )
#define X_SOURCE    ( 1 <<  9 )
#define X_BUSY      ( 1 << 10 )

#define B_LEFT_DROP             11
#define X_LEFT_DROP       (1 << B_LEFT_DROP)
#define B_LEFT_FREQ             12
#define X_LEFT_FREQ       (1 << B_LEFT_FREQ)
#define B_LEFT_DEPTH            13
#define X_LEFT_DEPTH      (1 << B_LEFT_DEPTH)

#define B_RIGHT_DROP             14
#define X_RIGHT_DROP       (1 << B_RIGHT_DROP)
#define B_RIGHT_FREQ             15
#define X_RIGHT_FREQ       (1 << B_RIGHT_FREQ)
#define B_RIGHT_DEPTH            16
#define X_RIGHT_DEPTH      (1 << B_RIGHT_DEPTH)

#define X_LEFT_REJECT     (X_LEFT_DROP | X_LEFT_FREQ | X_LEFT_DEPTH)
#define X_RIGHT_REJECT   (X_RIGHT_DROP | X_RIGHT_FREQ | X_RIGHT_DEPTH)



void fillbits
(  char* buf
,  unsigned bits
)
   {  int i, delta = 0
   ;  strncpy(buf, "ACGT,ACGT,@sbt", 16)
   ;  for (i=0;buf[i];i++)
      {  if (i/4 > delta)
         delta++
      ;  if (!(bits & (1 << i)))
         buf[i+delta] = ' '
   ;  }
   }


struct kannot                    /* kmer annotation */
{  kun kmer
;  double in_out_ratio
;  unsigned ccid                 /* connected component ID */
;  unsigned flags
;
}  ;


struct cc                        /* connected component */
{  unsigned  id
;  ctr       N
;  ctr       N_sink
;  ctr       N_source
;  ctr       N_bpoint
;  unsigned  skip
;
}  ;


#define OPT_ACCEPT_VERBOSE    1 << 0

struct df                        /* data frame */
{  struct kmer*   ls
;  unsigned       n_ls
;  struct kannot* ws             /* this represents the filtered set of kmers, the working set */
;  unsigned       n_ws
;  kun*           ccstack        /* size n_ws, working space */
;  ctr            n_sources      /* sources are put at end of ccstack */
;  unsigned       k
;  kun            kmask
;  unsigned       options
;  ZFILE          fpaccept
;  ZFILE          fpdebug
;  ZFILE          fpdata
                              /* fixme: bundle magic parameters */
;  double         io_xmax        /* maximum drop-off */
;  double         io_fmin        /* frequency of base */
;  double         io_tmin        /* transition depth (absolute number of base) */
;  unsigned       io_imin        /* absolute number of total kmer output */
;  unsigned       io_omin        /* absolute number of total kmer input */
;  unsigned       n_variant_source_max
;  unsigned       n_variant_component_max
;  unsigned       n_max_sources
;  unsigned       tailtri
;  unsigned       kmertri
;  struct cc*     ccannot        /* size n_ws, working space */
;
}  ;


struct kmer* ls_g = NULL;



int unrepeatiness
(  unsigned k
,  kun kmer
,  kun kmask
)
   {  int j
   ;  int n_diff_min = k
   ;  for (j=1;j<=3;j++)
      {  int i, n_diff = 0
      ;  kun shiftmer
         =  (  (  (kmer << (2 * j))
               |  (kmer >> (2 * (k-j)))
               )
            &  kmask
            )
      ;  kun xor = shiftmer ^ kmer
      ;  for (i=0;i<k;i++)
         if ((xor >> (2 * i)) & 3)
         n_diff++
      ;  if (n_diff_min > n_diff)
         n_diff_min = n_diff
   ;  }
      return n_diff_min
;  }



void fillbuf
(  char* buf
,  kun   kmer
,  unsigned k
)
   {  buf[k] = '\0'
   ;  while (k--)
      {  buf[k] = dna[kmer & 3]
      ;  kmer = kmer >> 2
   ;  }
   }


unsigned sift
(  struct df* df
,  ctr* siftinfo
)
   {  int i
   ;  ctr npass = 0
   ;  struct kmer *ls = df->ls
   ;  unsigned dictsize = df->n_ls

   ;  for (i=0; i<dictsize; i++)
      {  int pass = 0
      ;  if (ls[i].nout > 0 || ls[i].nin > 0)
         {  if (ls[i].nout < df->io_omin && ls[i].nin < df->io_imin)
            {  siftinfo[3]++
            ;  siftinfo[2] += ls[i].nout
         ;  }
            else
            {  pass = 1
            ;  siftinfo[5]++
            ;  siftinfo[4] += ls[i].nout
         ;  }
         }

         if (pass)
         npass++
      ;  else
            ls[i].nout = 0
         ,  ls[i].nin  = 0
   ;  }
      return npass
;  }


                           /* noteme added extra code to catch kmers with no out */
int cmp_kmer_out
(  const void* a
,  const void* b
)
   {  kun u1 = ((const struct kannot*) a)[0].kmer
   ;  kun u2 = ((const struct kannot*) b)[0].kmer
   ;  return ls_g[u1].nout < ls_g[u2].nout ? 1 : ls_g[u1].nout > ls_g[u2].nout ? -1 : 0
;  }

               /* use heap insert ...
                * top of heap is the smallest of the current set of values
                * we start with all zeroes 
               */
void get_top_by_out
(  struct df* df
,  unsigned topsize
)
   {  unsigned i
   ;  struct kmer *ls = df->ls
   ;  unsigned dictsize = df->n_ls
   ;  unsigned mytopsize = topsize | 1       /* make sure it's odd */
   ;  struct kannot* heap = calloc(mytopsize, sizeof heap[0])
   ;  struct kmer ls0 = ls[0]

   ;  df->ws   = heap

   ;  ls[0].nout  = 0             /* heap initialised to all-zero; points to AAA..AAA, temporarily set to zero */
   ;  ls[0].nin   = 0             /* heap initialised to all-zero; points to AAA..AAA, temporarily set to zero */

   ;  for (i=0;i<dictsize;i++)
      {  if (!ls[i].nout && ls[i].nin)                      /* dangersign invariant broken */
         ls[i].nout = 1
      ;  if (ls[i].nout > ls[heap[0].kmer].nout)
         {  unsigned p = 0                                /* parent */
         ;  unsigned c = 1
         ;  heap[0].kmer = i
         ;  while (c+1 < mytopsize)
            {  if (ls[heap[c+1].kmer].nout < ls[heap[c].kmer].nout)   /* take smallest of children */
               c++
            ;  if (ls[heap[p].kmer].nout > ls[heap[c].kmer].nout)
               {  heap[p] = heap[c]                       /* move smallest child up */
               ;  heap[c].kmer = i
               ;  p = c                                   /* next parent will be place of smallest child */
               ;  c = 2*p + 1
            ;  }
               else
               break
         ;  }
         }
      }
      ls_g = df->ls
   ;  ls[0] = ls0
   ;  qsort(df->ws, mytopsize, sizeof df->ws[0], cmp_kmer_out)
   ;  df->n_ws = topsize
;  }


ctr g_fieldtosmall = 0;

#define MAXFIELDSIZE 511


struct record
{  char seq       [MAXFIELDSIZE+1]
;  char q         [MAXFIELDSIZE+1]
;  char discard   [MAXFIELDSIZE+1]
;  char id        [MAXFIELDSIZE+1]

;  unsigned seq_n
;  unsigned q_n
;  unsigned discard_n
;  unsigned id_n

;  unsigned count
;  unsigned ID
;
}  ;


#define MINION_ERROR 3
#define MINION_NOMEM 2
#define MINION_DONE  1
#define MINION_OK    0


#define izblank(c) ((unsigned char) (c) == ' ' || (unsigned char) (c) == '\t')


int cpytofield
(  char* dest
,  char* src
,  int   n
)
   {  if (n > MAXFIELDSIZE)
         n = MAXFIELDSIZE
      ,  g_fieldtosmall++
   ;  memcpy(dest, src, n)
   ;  dest[n] = '\0'
   ;  return n
;  }


int read_record3
(  ZFILE  ip
,  struct file_buffer* fb
,  const char* format
,  struct record* rec
)
   {  const char* fmtp = format
   ;  unsigned rlstat = 0
#define LINE_LIMIT 8191
   ;  char buf[LINE_LIMIT+1]
   ;  unsigned n_received = 0
   ;  unsigned n_truncated = 0
   ;  char* bufp = NULL, *curp = NULL, *bufz = NULL
   ;  int esc = 0

   ;  rec->seq_n     =  0
   ;  rec->discard_n =  0
   ;  rec->q_n       =  0
   ;  rec->id_n      =  0
   ;  rec->count     =  1
   ;  rec->ID        =  0
   ;  rec->seq[0]    =  '\0'
   ;  rec->discard[0]=  '\0'
   ;  rec->q[0]      =  '\0'
   ;  rec->id[0]     =  '\0'

   ;  while (fmtp[0])
      {  if (!bufp)
         {  rlstat |= kraken_hookline(ip, fb, buf, LINE_LIMIT, &n_received, &n_truncated)
         ;  if (n_truncated || rlstat & (RL_DONE | RL_ERROR))
            break
         ;  bufp = buf
         ;  bufz = buf + n_received
         ;  esc  = 0
      ;  }
         curp = bufp

      ;  if (esc)
         {  switch((unsigned char) fmtp[0])
            {  case '#':
                  fmtp++
               ;  bufp = NULL
               ;  continue
               ;
            case 'n':
                  if (bufp != bufz)
                  goto DONE
               ;  fmtp++
               ;  bufp = NULL
               ;  continue
               ;
            case '%':
                  if (bufp[0] != '%') goto DONE
               ;  bufp++
               ;  break
               ;
            case 't':
                  if (bufp[0] != '\t') goto DONE
               ;  bufp++
               ;  break
               ;
            case 's':
                  if (bufp[0] != ' ') goto DONE
               ;  bufp++
               ;  break
               ;
            case '.':
                  bufp++
               ;  break
               ;
            case 'b':
                  while (bufp < bufz && izblank(bufp[0]))
                  bufp++
               ;  break
               ;
            case 'X': case 'C':
                  {  int n_scanned = 0
                  ;  if (sscanf(bufp, "%u%n", &rec->count, &n_scanned) < 1)
                     goto DONE
                  ;  bufp += n_scanned
               ;  }
                  break
               ;
            case 'J':
                  {  int n_scanned = 0
                  ;  if (sscanf(bufp, "%u%n", &rec->ID, &n_scanned) < 1)
                     goto DONE
                  ;  bufp += n_scanned
               ;  }
                  break
               ;
            case 'G':
                  while (bufp < bufz && !izblank((unsigned char) bufp[0]))
                  bufp++
               ;  break
               ;
            case 'F':
                  while (bufp < bufz && '\t' != (unsigned char) bufp[0])
                  bufp++
               ;  break
               ;
            case 'Q':
                  while (bufp < bufz && !izblank((unsigned char) bufp[0]))
                  bufp++
               ;  rec->q_n = cpytofield(rec->q, curp, bufp - curp)
               ;  break
               ;
            case 'I':
                  while (bufp < bufz && !izblank((unsigned char) bufp[0]))
                  bufp++
               ;  rec->id_n = cpytofield(rec->id, curp, bufp - curp)
               ;  break
               ;
            case 'R':
                  while (bufp < bufz && isalpha((unsigned char) bufp[0]))
                     bufp[0] = toupper((unsigned char) bufp[0])
                  ,  bufp++
               ;  rec->seq_n = cpytofield(rec->seq, curp, bufp - curp)
               ;  break
               ;
            default:
                  goto DONE
         ;  }
            esc = 0
      ;  }
         else
         {  if (fmtp[0] == '%')
            esc = 1
         ;  else if (bufp[0] != fmtp[0])
            goto DONE
         ;  else
            bufp++
      ;  }
         fmtp++
   ;  }

      DONE :

      if (n_truncated)
         argh("minion", "line too long")
      ,  rlstat |= RL_ERROR

   ;  if (fmtp > format && (fmtp[0] || (bufp && bufp - buf != n_received)))
      {  argh("tally", "parse error (remaining format string [%s], buffer [%s])", fmtp, bufp)
      ;  return MINION_ERROR
   ;  }

      if (rlstat & RL_DONE)
      return MINION_DONE

   ;  if (rlstat & RL_ERROR)
      return MINION_ERROR

   ;  if (rlstat & RL_NOMEM)           /* fixme not checked yet */
      return MINION_NOMEM

   ;  return MINION_OK
;  }


unsigned kmer_from_buf(const char* buf, unsigned K, unsigned* m)
   {  unsigned hid = 0
   ;  unsigned mask = 0
   ;  int i
   ;  for (i=0;i<K;i++)
      {  unsigned b = themap[(unsigned char) buf[i]]
      ;  mask = mask << 1
      ;  if (b >= 4)
         mask |= 1
      ;  else
         hid |= b << 2*(K-1-i)
   ;  }
      *m = mask
   ;  return hid
;  }


unsigned parse_sequencex         /* artificially introduce gap into k-mer at position p(arameter) */
(  struct df* df
,  const char* s
,  int n
,  unsigned duplicity
,  unsigned seq_id
,  ctr count[2]
)
   {  int i = 0
   ;  struct kmer* ls = df->ls
   ;  unsigned k      = df->k
   ;  kun kmask  = df->kmask
   ;  kun kmer  = 0
   ;  unsigned nbits = 0
   ;  unsigned nmask = (1 << (k+1)) - 1         /* note: mask for k+1-mer */
   ;  unsigned index[64] = { 0 }
   ;  unsigned n_tri = 0, n_skipped = 0

   ;  for (i=0;i<n;i++)
      {  unsigned b = BASEMAP((unsigned char) s[i])
      ;  unsigned tri_in  = ((kmer << 2) | b) & 63
      ;  unsigned tri_out = (kmer >> (2*k-6)) & 63

      ;  nbits = nbits << 1
      ;  if (b > 3)
         nbits |= 1

      ;  if (i >= 2 && !(nbits & 7))
         n_tri += (index[tri_in]++ == 0)

      ;  if (i >= k && !((nbits >> (k-2)) & 7))
         n_tri -= (index[tri_out]-- == 1)

;if(0)fprintf(stderr, "ntri %d (i/o %d %d N %d %d)\n", ji n_tri, ji tri_in, ji tri_out, ji (nbits & 7), ji ((nbits >> (k-2)) & 7))
      ;  if (i >= k)
         {  if (!(nmask & nbits) && n_tri >= df->kmertri)
            {  ls[kmer & kmask].ttr[b] += duplicity
            ;  count[0] += duplicity
            ;  count[1] += ls[kmer & kmask].nout == 0
            ;  ls[kmer & kmask].nout += duplicity
            ;  ls[((kmer << 2) | b) & kmask].nin += duplicity
         ;  }
            else if (n_tri < df->kmertri)
            n_skipped++
      ;  }
         kmer = (kmer << 2) | b           /* screws kmer up if N etc, but will be shifted out */
   ;  }
      return n_skipped
;  }

unsigned parse_sequence
(  struct df* df
,  const char* s
,  int n
,  unsigned duplicity
,  unsigned seq_id
,  ctr count[2]
)
   {  int i = 0
   ;  struct kmer* ls = df->ls
   ;  unsigned k      = df->k
   ;  kun kmask  = df->kmask
   ;  kun kmer  = 0
   ;  unsigned nbits = 0
   ;  unsigned nmask = (1 << (k+1)) - 1         /* note: mask for k+1-mer */
   ;  unsigned index[64] = { 0 }
   ;  unsigned n_tri = 0, n_skipped = 0

   ;  for (i=0;i<n;i++)
      {  unsigned b = BASEMAP((unsigned char) s[i])
      ;  unsigned tri_in  = ((kmer << 2) | b) & 63
      ;  unsigned tri_out = (kmer >> (2*k-6)) & 63

      ;  nbits = nbits << 1
      ;  if (b > 3)
         nbits |= 1

      ;  if (i >= 2 && !(nbits & 7))
         n_tri += (index[tri_in]++ == 0)

      ;  if (i >= k && !((nbits >> (k-2)) & 7))
         n_tri -= (index[tri_out]-- == 1)

;if(0)fprintf(stderr, "ntri %d (i/o %d %d N %d %d)\n", ji n_tri, ji tri_in, ji tri_out, ji (nbits & 7), ji ((nbits >> (k-2)) & 7))
      ;  if (i >= k)
         {  if (!(nmask & nbits) && n_tri >= df->kmertri)
            {  ls[kmer & kmask].ttr[b] += duplicity
            ;  count[0] += duplicity
            ;  count[1] += ls[kmer & kmask].nout == 0
            ;  ls[kmer & kmask].nout += duplicity
            ;  ls[((kmer << 2) | b) & kmask].nin += duplicity
         ;  }
            else if (n_tri < df->kmertri)
            n_skipped++
      ;  }
         kmer = (kmer << 2) | b           /* screws kmer up if N etc, but will be shifted out */
   ;  }
      return n_skipped
;  }


unsigned nroffbits
(  unsigned v
)
   {  const unsigned char lut[16] = {0,1,1,2,1,2,2,3,1,2,2,3,2,3,3,4}
   ;  return lut[v & 0x0f] + lut[v >> 4]
;  }


unsigned consider_shift3
(  kun kmer
,  struct df* df
,  unsigned char nb[4]
)
   {  int ho            =  df->ls[kmer].heap_offset
   ;  ctr* ttr          =  df->ls[kmer].ttr
   ;  struct kannot* ka =  ho < 0 ? NULL : df->ws+ho
   ;  unsigned n = 0
   ;  unsigned char nb2[4]

   ;  if (!ka)
      return 0

   ;  if (ka->flags & X_RIGHT_A)
      nb[n++] = 0
   ;  if (ka->flags & X_RIGHT_C)
      nb[n++] = 1
   ;  if (ka->flags & X_RIGHT_G)
      nb[n++] = 2
   ;  if (ka->flags & X_RIGHT_T)
      nb[n++] = 3

   ;  if (n <= 1) return n
   ;  memcpy(nb2, nb, 4)

   ;  if (ttr[nb[1]] > ttr[nb[0]])
         nb[1] = nb[0]
      ,  nb[0] = nb2[1]

   ;  if (n == 2) return 2
                                    /* now first two elements sorted */
   ;  if (ttr[nb[2]] > ttr[nb[0]])
      {  memmove(nb+1, nb, 2)
      ;  nb[0] = nb2[2]
   ;  }
      else if (ttr[nb[2]] > ttr[nb[1]])
         nb[2] = nb[1]
      ,  nb[1] = nb2[2]

   ;  if (n == 3) return 3
                                    /* now first three elements sorted */
   ;  {  int i
      ;  for (i=3; i>0; i--)
         if (ttr[nb[i-1]] > ttr[nb[3]])
         break
      ;  if (i != 3)
            memmove(nb+i+1, nb+i, 3-i)
         ,  nb[i] = nb2[3]
   ;  }
      return 4
;  }




   /* return value: the number of matching nucleotides.
   */
int match_kmers
(  kun left
,  kun right
,  unsigned k
)
   {  int i = 0
   ;  kun kmask = (1 << (2*k)) - 1
   ;  for (i=0;i<k;i++)
      if (  (left & (kmask >> 2*i)) == ((right >> 2*i)  & kmask))
      break
   ;  return k-i
;  }


int test_sequence
(  const char* msg
,  char* buf
,  int n
,  int i_variant
,  int n_cycle
,  ctr max_seen
,  kun kmer_start
,  kun kmer_end
,  struct df* df
,  struct kannot* annot
)
   {  unsigned k = df->k
   ;  int vb = df->options & OPT_ACCEPT_VERBOSE
   ;

      if (vb)
      {  int p = k, i
      ;  kun mymer
      ;  char az[] = "0n1u2d3t4q5c6s7"

      ;  fprintf(df->fpaccept, "acc\n")
      ;  fprintf(df->fpaccept, "accepti ---------- ")    /* kmer input */
      ;  for (mymer = kmer_start, p=k;p<=n;p++)
         {  kun mymer_next    =  ((mymer << 2) | BASEMAP((unsigned char) buf[p])) & df->kmask
         ;  unsigned logit    =  0.5 + log(df->ls[mymer].nin * 1.0) / log(sqrt(10.0))
         ;  if (logit > 14)
            logit = 14
         ;  fputc(az[logit], df->fpaccept)
         ;  mymer = mymer_next
      ;  }
         fputc('\n', df->fpaccept)

      ;  mymer = kmer_start
      ;  fprintf(df->fpaccept, "accepto ---------- ")    /* kmer output */
      ;  for (mymer = kmer_start, p=k;p<=n;p++)
         {  kun mymer_next    =  ((mymer << 2) | BASEMAP((unsigned char) buf[p])) & df->kmask
         ;  unsigned logit    =  0.5 + log(df->ls[mymer].nout * 1.0) / log(sqrt(10.0))
         ;  if (logit > 14)
            logit = 14
         ;  fputc(az[logit], df->fpaccept)
         ;  mymer = mymer_next
      ;  }
         fputc('\n', df->fpaccept)

      ;  mymer = kmer_start
      ;  fprintf(df->fpaccept, "acceptx ---------- ")    /* drop-off and skew */
      ;  for (i=0;i<k-1;i++) fputc(' ', df->fpaccept)
      ;  for (mymer = kmer_start, p=k;p<n;p++)
         {  kun mymer_next    =  ((mymer << 2) | BASEMAP((unsigned char) buf[p])) & df->kmask
         ;  unsigned char c   =  '0' + (int) (0.5 + (df->ls[mymer].ttr[mymer_next & 3] * 10.0 / df->ls[mymer].nout))
         ;  fputc(c, df->fpaccept)
#if 0
         ;  int ho            =  df->ls[mymer].heap_offset
         ;  unsigned fl       =  ho < 0 ? 1 : df->ws[ho].flags
         ;  unsigned char c
            =     fl == 1
               ? '!'
               :  fl & X_RIGHT_DEPTH
               ?  'd'
               :  fl == (X_RIGHT_DROP | X_RIGHT_FREQ)
               ?  'e'
               :  fl == X_RIGHT_FREQ
               ?  'f'
               :  fl == X_RIGHT_DROP
               ?  'x'
               :  '-'
         ;  fputc(c, df->fpaccept)
#endif
         ;  mymer = mymer_next
      ;  }
         fputs("!\n", df->fpaccept)

      ;  mymer = kmer_start
      ;  fprintf(df->fpaccept, "acceptr ---------- ")    /* right looking */
      ;  for (i=0;i<k-1;i++) fputc(' ', df->fpaccept)
      ;  for (mymer = kmer_start, p=k;p<=n;p++)
         {  kun mymer_next    =  ((mymer << 2) | BASEMAP((unsigned char) buf[p])) & df->kmask
         ;  int ho            =  df->ls[mymer].heap_offset
         ;  unsigned n_consider = ho < 0 ? 0 : nroffbits(df->ws[ho].flags & X_RIGHT_STAR)
         ;  fputc(n_consider == 0 ? '!' : n_consider == 1 ? '-' : '0' + n_consider, df->fpaccept)
         ;  mymer = mymer_next
      ;  }
         fputc('\n', df->fpaccept)

      ;  mymer = kmer_start
      ;  fprintf(df->fpaccept, "acceptx ---------- !")    /* drop-off and skew */
      ;  for (mymer = kmer_start, p=k;p<n;p++)
         {  kun mymer_next    =  ((mymer << 2) | BASEMAP((unsigned char) buf[p])) & df->kmask
         ;  unsigned char c   =  '0' + (int) (0.5 + (df->ls[mymer].ttr[mymer_next & 3] * 10.0 / df->ls[mymer_next].nin))
         ;  fputc(c, df->fpaccept)
#if 0
         ;  int ho            =  df->ls[mymer].heap_offset
         ;  unsigned fl       =  ho < 0 ? 1 : df->ws[ho].flags
         ;  unsigned char c
            =     fl == 1
               ? '!'
               :  fl & X_LEFT_DEPTH
               ?  'd'
               :  fl == (X_LEFT_DROP | X_LEFT_FREQ)
               ?  'e'
               :  fl == X_LEFT_FREQ
               ?  'f'
               :  fl == X_LEFT_DROP
               ?  'x'
               :  '-'
         ;  fputc(c, df->fpaccept)
#endif
         ;  mymer = mymer_next
      ;  }
         fputc('\n', df->fpaccept)

      ;  mymer = kmer_start
      ;  fprintf(df->fpaccept, "acceptl ---------- ")    /* left looking */
      ;  for (mymer = kmer_start, p=k;p<=n;p++)
         {  kun mymer_next    =  ((mymer << 2) | BASEMAP((unsigned char) buf[p])) & df->kmask
         ;  int ho            =  df->ls[mymer].heap_offset
         ;  unsigned n_consider = ho < 0 ? 0 : nroffbits(df->ws[ho].flags & X_LEFT_STAR)
         ;  fputc(n_consider == 0 ? '!' : n_consider == 1 ? '-' : '0' + n_consider, df->fpaccept)
         ;  mymer = mymer_next
      ;  }
         fputc('\n', df->fpaccept)

   ;  }

      fprintf
      (  df->fpaccept
      ,  "acceptm %3u %2d %3d %s [F %lu/%lu %lu %lu/%lu] [type %s] [N,a,m,z %u %u %u %u] [cycle %d]\n"

      ,  ju df->ws[df->ls[kmer_start].heap_offset].ccid
      ,  ji i_variant
      ,  ji n
      ,  buf

      ,  lu df->ls[kmer_start].nin
      ,  lu df->ls[kmer_start].nout
      ,  lu max_seen
      ,  lu df->ls[kmer_end].nin
      ,  lu df->ls[kmer_end].nout

      ,  msg

      ,  ju df->ccannot[df->ws[df->ls[kmer_start].heap_offset].ccid].N
      ,  ju df->ccannot[df->ws[df->ls[kmer_start].heap_offset].ccid].N_source
      ,  ju df->ccannot[df->ws[df->ls[kmer_start].heap_offset].ccid].N_bpoint
      ,  ju df->ccannot[df->ws[df->ls[kmer_start].heap_offset].ccid].N_sink

      ,  ji n_cycle
      )
   ;  if (0 && vb)
      fprintf(df->fpaccept, "###### %.*s\n", n, buf)
   ;  return 1
;  }

                                    /* fixme; bit expensive perhaps to recurse for traversal.
                                     * It's very convenient though.
                                    */
ctr unroll_sequence1
(  char* buf
,  int n_buf
,  int i_buf            /* write next base here */
,  int* n_variants
,  int* n_cycle
,  ctr* max_seen
,  kun root
,  kun kmer
,  struct df* df
)
   {  struct kmer* ls = df->ls
   ;  struct kannot* ws = df->ws
   ;  kun kmask = df->kmask
   ;  unsigned char nb[4] = { 0 }
   ;  int ret = 0
   ;  int i = 0

   ;  unsigned n_consider = consider_shift3(kmer, df, nb)

#ifdef KMER_DEBUG
;if(kmer == KMER_DEBUG)fprintf(stderr, "%d %d %d %d %d %d flags %d\n", KMER_DEBUG, n_consider, ji nb[0], ji nb[1], ji nb[2], ji nb[3], ji df->ws[df->ls[kmer].heap_offset].flags)
#endif

   ;  if (n_variants[0] >= df->n_variant_source_max)                  /* fixme magic constant */
      return 0

   ;  buf[i_buf] = '\0'

   ;  if (i_buf == n_buf || !n_consider)
      {  const char* msg = !n_consider ? "curtains" : "cutoff"
      ;  if (test_sequence(msg, buf, i_buf, n_variants[0], n_cycle[0], max_seen[0], root, kmer, df, NULL))
         {  n_variants[0]++
         ;  ret++ 
      ;  }
         else
         return 0
   ;  }

                              /* fixme: if accepted with prefix, the prefix can be something
                               * previously discarded -- ideally check on accepted only
                              */
      for (i=0; i< n_consider; i++)
      {  unsigned j = nb[i]
      ;  kun shiftmer = (kmer << 2 | j) & kmask 
      ;  ctr max_seen2 = max_seen[0]
      ;  struct kannot* shiftannot = ws+ls[shiftmer].heap_offset

      ;  if (shiftannot->flags & X_BUSY)           /* already seen in this consensus read */
         {  n_cycle[0]++
;if (df->fpdebug)fprintf(df->fpaccept, "cycle\n")
         ;  continue
      ;  }
         shiftannot->flags  |= X_BUSY

      ;  if (df->ls[shiftmer].nout > max_seen2)
         max_seen2 = df->ls[shiftmer].nout

      ;  buf[i_buf] = dna[j]
      ;  buf[i_buf+1] = '\0'
                                                   /* start of consensus sequence already accepted */
                                                   /* fixme: expand_component should prevent this?
                                                    * note that io tilt introduces *extra* breaks.
                                                   */
      ;  if (shiftannot->flags & X_SOURCE)
         {  if (test_sequence("prefix", buf, i_buf+1, n_variants[0], n_cycle[0], max_seen2, root, shiftmer, df, shiftannot))
            {  n_variants[0]++
            ;  ret++
         ;  }
         }
         else
         {  shiftannot->flags |= X_SEEN
         ;  ret += unroll_sequence1(buf, n_buf, i_buf+1, n_variants, n_cycle, &max_seen2, root, shiftmer, df)
      ;  }
         shiftannot->flags ^= X_BUSY
   ;  }
      return ret
;  }



void annotate_top
(  struct df* df
)
   {  ZFILE fp = df->fpdata
   ;  struct kmer* ls = df->ls
   ;  unsigned dictsize = df->n_ls
   ;  struct kannot* ws = df->ws
   ;  unsigned topsize  = df->n_ws
   ;  unsigned k        = df->k

   ;  int i
   ;  char buf[128]

   ;  for (i=0; i< dictsize;i++)
      ls[i].heap_offset = -1

   ;  if (fp)
      gzprintf(fp, "kmer\tnmer\t#in\t#out\t#leftA\tA\t#leftC\tC\t#leftG\tG\t#leftT\tT\t#rightA\tA\t#rightC\tC\t#rightG\tG\t#rightT\tT\tior\tpskew\tsskew\n")

   ;  for (i=0;i<topsize;i++)
      {  kun kmer = ws[i].kmer
      ;  struct kannot* kan = ws+i
      ;  int j

      ;  ls[kmer].heap_offset = i

      ;  fillbuf(buf, kmer, k)
      ;  if (fp)
         gzprintf(fp, "%s\t%d\t%d\t%d", buf, ji kmer, ji ls[kmer].nin, ji ls[kmer].nout)
      ;  for (j=0;j<4;j++)
         {  kun prefix = (j << (2 *k -2)) | (kmer >> 2) 
         ;  if (fp)
            gzprintf(fp, "\t%d\t%c", ls[prefix].ttr[kmer & 3], dna[j])
      ;  }
         for (j=0;j<4;j++)
         {  if (fp)
            gzprintf(fp, "\t%d\t%c", ls[kmer].ttr[j], dna[j])
      ;  }
         kan->in_out_ratio = (1+ls[kmer].nin) * 1.0 / (1+ls[kmer].nout)
      ;  if (fp)
         gzprintf(fp, "\t%.1f\n", kan->in_out_ratio)
   ;  }
   }


                              /* hierverder.
                                 The way forward is to beat this into shape.
                                 Good logic for marking as 'done'
                                 while making sure edges are marked on both sides (left and right kmer)
                              */
void expand_component
(  struct df *df
,  kun kmer
,  unsigned id
,  struct cc* ccannot
)
   {  int i_stack = 1, n_seen = 1
   ;  kun kmask = df->kmask
   ;  unsigned k     = df->k
   ;  char buf[64]
   ;  char buf2[64]
   ;  kun* stack = df->ccstack    /* size df->n_ws */
;int debug = 0

   ;  stack[0] = kmer

   ;  fillbuf(buf, kmer, k)

#if DEBUG_ON
   ;  if (df->fpdebug)
      fprintf(df->fpdebug, "\nstart %s in component %d\n", buf, ji id)
#endif

   ;  while (i_stack > 0)
      {  kun thismer  =  stack[i_stack-1]
      ;  unsigned n_left   =  0
      ;  unsigned n_right  =  0
      ;  int ho            =  df->ls[thismer].heap_offset
      ;  struct kannot* an =  ho < 0 ? NULL : df->ws+ho
      ;  struct kmer*   km =  df->ls+thismer        /* kmer middle */
      ;  int j

      ;  fillbuf(buf, thismer, k)
      ;  i_stack--

      ;  if (!an || an->ccid > 0)                   /* !an should not happen */
         continue

      ;  an->ccid  = id


;if(0)an->flags = 0

;if(0)fprintf(stderr, "stack %d top %s id %d\n", ji i_stack, buf, an->ccid)
;if (0 && debug++ > 40)
exit(1)
      ;  for (j=0;j<4;j++)
         {  kun ttr           =  ((thismer << 2) | j) & kmask                    /* to the right */
         ;  kun ttl           =  ((thismer >> 2) | (j << (2*k-2))) & kmask       /* to the left  */
         ;  struct kmer* kr   =  df->ls+ttr
         ;  struct kmer* kl   =  df->ls+ttl
         ;  int hr            =  kr->heap_offset
         ;  int hl            =  kl->heap_offset
         ;  struct kannot* ar =  hr >= 0 ? df->ws+hr : NULL
         ;  struct kannot* al =  hl >= 0 ? df->ws+hl : NULL

         ;  if (ar)
            {  const char* msg = "rskip"
            ;  unsigned freq_ok
               =     km->ttr[j] >= km->nout * df->io_fmin 
                  && km->ttr[j] >= kr->nin * df->io_fmin 
            ;  unsigned band_ok
               =     kr->nin * df->io_xmax >= km->nout
                  && kr->nin <= km->nout * df->io_xmax
            ;  unsigned depth_ok = km->ttr[j] >= df->io_tmin

            ;  an->flags |= ((1-freq_ok) << B_RIGHT_FREQ) | ((1-band_ok) << B_RIGHT_DROP) | ((1-depth_ok) << B_RIGHT_DEPTH)
            ;  if (freq_ok * band_ok * depth_ok)
               {  n_seen++
               ;  n_right++
               ;  msg = "pickr"
               ;  an->flags |= 1 << (4+j)                /* danger sign; X_RIGHT_A ... X_RIGHT_T */
               ;  if (!ar->ccid)
                  stack[i_stack++] = ttr
               ;  else if (ar->ccid != id)
                  argh("_^^_", "no right symmetry :-(")
            ;  }


#if DEBUG_ON
               fillbuf(buf2, ttr, k)
            ;  if (df->fpdebug)
               fprintf
               (  df->fpdebug
               ,  "%s from %s to %s test %d %d %d %d\n"
               ,  msg, buf, buf2
               ,  km->ttr[j] >= km->nout * df->io_fmin 
               ,  km->ttr[j] >= kr->nin * df->io_fmin 
               ,  kr->nin * df->io_xmax >= km->nout
               ,  kr->nin <= km->nout * df->io_xmax
               )
#endif
         ;  }

            if (al)
            {  const char* msg = "lskip"
            ;  unsigned freq_ok
               =     kl->ttr[thismer & 3] >= kl->nout * df->io_fmin 
                  && kl->ttr[thismer & 3] >= km->nin  * df->io_fmin 
            ;  unsigned band_ok
               =     kl->nout * df->io_xmax >= km->nin
                  && kl->nout <= km->nin * df->io_xmax
            ;  unsigned depth_ok = kl->ttr[thismer & 3] >= df->io_tmin

            ;  an->flags |= ((1-freq_ok) << B_LEFT_FREQ) | ((1-band_ok) << B_LEFT_DROP) | ((1-depth_ok) << B_LEFT_DEPTH)
            ;  if (freq_ok * band_ok * depth_ok)
               {  n_seen++
               ;  n_left++
               ;  msg = "pickl"
               ;  an->flags |= 1 << j                    /* danger sign; X_LEFT_A ... X_LEFT_T */
               ;  if (!al->ccid)
                  stack[i_stack++] = ttl
               ;  else if (al->ccid != id)
                  argh("_^^_", "no left symmetry :-(")
            ;  }
#if DEBUG_ON
               fillbuf(buf2, ttl, k)
            ;  if (df->fpdebug)
               fprintf
               (  df->fpdebug
               ,  "%s from %s to %s test %d %d %d %d\n"
               ,  msg, buf, buf2
               ,  kl->ttr[thismer & 3] >= kl->nout * df->io_fmin 
               ,  kl->ttr[thismer & 3] >= km->nin  * df->io_fmin 
               ,  kl->nout * df->io_xmax >= km->nin
               ,  kl->nout <= km->nin * df->io_xmax
               )
#endif
         ;  }
         }

      ;  if (!n_right)
         ccannot->N_sink++

      ;  if (!n_left)
            stack[df->n_ws - ++df->n_sources] = thismer
         ,  ccannot->N_source++

      ;  ccannot->N_bpoint += (n_left > 1) || (n_right > 1)

#if DEBUG_ON
      ;  if (df->fpdebug)
         {  fillbuf(buf, thismer, k)
         ;  if (!n_right)
            fprintf(df->fpdebug, "  sink %s %d\n", buf, n_left)
         ;  if (!n_left)
            fprintf(df->fpdebug, "  source %s %d\n", buf, n_right)
         ;  if (n_left && n_right)
            fprintf(df->fpdebug, "  node %s %d %d\n", buf, n_left, n_right)
      ;  }
#endif

   ;  }
      ccannot->N = n_seen
;  }


#define N_TRACK_CCANNOT 10000


void compute_cc
(  struct df* df
)
   {  unsigned i = 0, i_cc = 1
   ;  unsigned topsize = df->n_ws
   ;  df->ccstack = calloc(topsize, sizeof df->ccstack[0])
   ;  char buf[64]

   ;  while (1)
      {  struct cc *ccannot = df->ccannot+i_cc
      ;  while (i < topsize && df->ws[i].ccid)         /* seen as adapter or in cc */
         i++
      ;  if (i >= topsize)
         break

      ;  ccannot->id = i_cc
      ;  expand_component(df, df->ws[i].kmer, i_cc, ccannot)

      ;  if (i_cc == 100)
         argh("minion", "further leads suppressed")
      ;  if(i_cc < 100)
            fillbuf(buf, df->ws[i].kmer, df->k)
         ,  argh
            (  "~%~%~%"
            ,  "lead %s count %u component %d size %d source %d sink %d"
            ,  buf
            ,  ju df->ls[df->ws[i].kmer].nout
            ,  ji i_cc
            ,  ji ccannot->N
            ,  ji ccannot->N_source
            ,  ji ccannot->N_sink
            )

      ;  i_cc++
      ;  if (i_cc >= N_TRACK_CCANNOT || i_cc >= df->n_max_sources)
         break
   ;  }
   }


                        /* hierverder; perhaps make sure that we are working in a single component?
                         * expand_component defines components, sources, sinks.
                         * missing sinks may have to do with io_ratio .. or similar criterion.
                         * trace_sequences + unroll_sequence1 work in parallel, ish.
                        */
void trace_sequences
(  struct df* df
,  int N
)
   {  unsigned i  = 0
   ;  ctr n_hit   = 0
   ;  ctr n_source= 0
   ;  char buf[512]
   ;  kun ccid_prev = 0
   ;  int n_component_variants = 0

   ;  argh("minion", "rolling in the deep (%u sources)", ju df->n_sources)
   ;  for (i=0; i<df->n_sources; i++)
      {  int ho = -1
      ;  int n_cycle = 0
      ;  kun start = df->ccstack[df->n_ws-i-1]
      ;  ctr max_seen = df->ls[start].nout
      ;  struct cc* can
      ;  int n_variants = 0

      ;  ho = df->ls[start].heap_offset
      ;  fillbuf(buf, start, df->k)

      ;  if (ho < 0)
         {  argh("minion", "skip %s", buf)
         ;  continue
      ;  }

         df->ws[ho].flags |= X_SOURCE | X_BUSY
      ;  can = df->ccannot+df->ws[ho].ccid

      ;  if (can->id != ccid_prev)
         n_component_variants = 0

      ;  ccid_prev = can->id

      ;  if (n_component_variants < df->n_variant_component_max)
         {  fprintf
            (  df->fpaccept
            ,  "search %s (io %d/%d) in component %u\n"
            ,  buf
            ,  ji df->ls[start].nin
            ,  ji df->ls[start].nout
            ,  ju df->ws[ho].ccid
            )
         ;  n_hit += unroll_sequence1(buf, 511, df->k, &n_variants, &n_cycle, &max_seen, start, start, df)
         ;  n_component_variants += n_variants
      ;  }

         df->ws[ho].flags ^= X_BUSY
      ;  if (N && ++n_source >= N)
         break
   ;  }
      argh("minion", "luctor et emergo (%u sequences found)", ju n_hit)
;  }


void output_settings
(  struct df* df
)
   {  argh("minion", "settings used:")
   ;  fprintf(stderr, " -max-x       %8g  maximum drop-off between k-mers\n", df->io_xmax)
   ;  fprintf(stderr, " -min-i       %8d  minimal required input of a node\n", df->io_imin)
   ;  fprintf(stderr, " -min-o       %8d  minimal required output of a node\n", df->io_omin)
   ;  fprintf(stderr, " -min-t       %8g  minimal required depth for any transition\n", df->io_tmin)
   ;  fprintf(stderr, " -min-f       %8g  minimal required base frequency for variant junctions\n", df->io_fmin)
   ;  fprintf(stderr, " -r           %8d  minimal required trimer count\n", df->kmertri)
   ;  fprintf(stderr, " -N           %8d  maximal number of components to analyse\n", df->n_max_sources)
   ;  fprintf(stderr, " -tri-check   %8d  dust-type complexity criterion for stripping read suffixes\n", df->tailtri)
   ;  fprintf(stderr, " -k           %8d  word length\n", df->k)
;  }


int minion_main
(  int argc
,  const char* argv[]
)
   {  ZFILE input = NULL
   ;  const char* g_fnin = "-"
   ;  const char* fndata = NULL, *fnout = "-", *fndebug = NULL
   ;  const char* theaptr = NULL
   ;  const char* g_format_in = "@%#%R%n%#%Q%n"
   ;  unsigned n_truncated = 0
   ;  unsigned nread = 0
   ;  struct df df = { 0 }
   ;  int status = 31
   ;  const char* gzopenmode = ZWMODE
   ;  unsigned id_prev = 0
   ;  int zippit = 1
   ;  int old_skool = 0
   ;  int limit = 0
   ;  int minionmode = 0

   ;  struct record rec    =  { { 0 }, { 0 }, { 0 }, { 0 }, 0 }

   ;  struct kmer* ls = NULL

   ;  struct file_buffer fb1 = { { 0 }, 0 }

   ;  kraken_readline(NULL, NULL, 0, NULL, &n_truncated)            /* resets static buffers */
   ;  kraken_hookline(NULL, &fb1, NULL, 0, NULL, &n_truncated)      /* resets buffers */

   ;  themap['A'] = 0
   ;  themap['C'] = 1
   ;  themap['G'] = 2
   ;  themap['T'] = 3
   ;  themap['N'] = 4
   ;  themap['X'] = 4

   ;  if
      (  argc < 2
      || (  strcmp(argv[1], "search-adapter")
         && strcmp(argv[1], "clean-data")
         && strcmp(argv[1], "tiny-test")
         && strcmp(argv[1], "gauge-adapter")
         )
      )
      {  argh("minion", "Usage: minion <search-adapter|clean-data|tiny-test|gauge-adapter> [options]")
      ;  exit(1)
   ;  }

      df.tailtri  = 20
   ;  df.kmertri  = 4
   ;  df.io_xmax  = 5.0
   ;  df.n_variant_source_max = 10
   ;  df.n_variant_component_max = 100
   ;  df.n_max_sources = 0

   ;  if (!strcmp(argv[1], "search-adapter"))
      {  df.k        =  12
      ;  df.io_fmin  =  0.6
      ;  df.io_xmax  =  2.0
      ;  df.io_tmin  =  100
      ;  df.io_imin  =  100
      ;  df.io_omin  =  100
      ;  df.n_max_sources =  10
   ;  }
      else if (!strcmp(argv[1], "clean-data"))
      {  df.k       =   14
      ;  df.io_fmin =   0.2
      ;  df.io_xmax =   5.0
      ;  df.io_tmin =   10
      ;  df.io_imin =   20
      ;  df.io_omin =   20
      ;  df.n_max_sources =  1000
   ;  }
      else if (!strcmp(argv[1], "tiny-test"))
      {  df.k       =   7
      ;  df.io_fmin =   0.2
      ;  df.io_tmin  =  0
      ;  df.io_imin =   0
      ;  df.io_omin =   0
      ;  df.kmertri =   0
      ;  df.n_max_sources =  200
   ;  }
      else if (!strcmp(argv[1], "gauge-adapter"))
      {  minionmode  = 'a'
      ;  df.kmertri  =  0
      ;  df.io_tmin  =  3
      ;  df.io_imin  =  3
      ;  df.io_omin  =  3
   ;  }

         arg_switch2()

      optarg("-record-format") g_format_in = thearg(); endarg()

      optarg("-o")   fnout   = thearg(); endarg()
      optarg("-do")  limit   = atoi(thearg());   endarg()
      optarg("-i")   g_fnin  = thearg(); endarg()
      optarg("-d")   fndata  = thearg(); endarg()
      optarg("-e")   fndebug = thearg(); endarg()
      optarg("-adapter") theaptr = thearg(); endarg()
      optarg("-k")   df.k    = atoi(thearg()); endarg()
      optarg("-r")   df.kmertri        = atoi(thearg()); endarg()
      optarg("-nos")   df.n_max_sources       = atoi(thearg()); endarg()
      optarg("-min-i")  df.io_imin    = atoi(thearg()); endarg()
      optarg("-min-o")  df.io_omin    = atoi(thearg()); endarg()
      optarg("-min-t")  df.io_tmin    = atoi(thearg()); endarg()
      optarg("-min-io") df.io_omin = df.io_imin = atoi(thearg()); endarg()
      optarg("-max-x")  df.io_xmax = atof(thearg()); endarg()
      optarg("-min-f")  df.io_fmin    = atof(thearg()); endarg()
      optarg("-nvar")   df.n_variant_source_max = atoi(thearg()); endarg()
      optarg("-tri-check") df.tailtri  = atoi(thearg()); endarg()

      uniarg("--verbose")         df.options |= OPT_ACCEPT_VERBOSE; endarg()
      uniarg("-z") output_settings(&df); exit(0); endarg()
      uniarg("--old-skool")  old_skool = 1; endarg()

      uniarg("-h")
puts("-o <fname>        output stream (default STDOUT)");
puts("-i <fname>        input stream (gzipped file allowed) (default STDIN)");
puts("-d <fname>        (gzipped!) data stream (de Bruijn graph representation)");
puts("-e <fname>        debug output stream");
puts("-k <int>          kmer size (k)");
puts("-r <int>          minimal required k-mer tri-nucleotide content");
puts("-nos <int>        maximum number of sources to consider");
puts("-min-i <int>      minimum required input of a kmer");
puts("-min-o <int>      minimum required output of a kmer");
puts("-max-x <num>      maximum allowed drop-off between nodes");
puts("-min-f <num>      minimum required base frequency between variant junctions");
puts("-tri-check <int>  dust-type criterion for trimming read tails");
puts("-nvar <int>       maximum number of variants to track per graph component");
puts("-adapter <oligo>  adapter to analyse in gauge-adapter mode");
puts("--verbose         increase verbosity output levels");
puts("   Use -z to see defaults");
status = 0;
X_ERR_JUMP(DONE, "DON'T PANIC");
      endarg()

      uniarg("--nozip") zippit = 0; endarg()
      uniarg("--version")
fprintf(stdout, "minion version: %s\n", minion_tag);
status = 0;
goto DONE;
      endarg()

      failarg()
      arg_done()

   ;  if (minionmode == 'a' && (!theaptr || strlen(theaptr) < df.k))
      X_ERR_JUMP(DONE, "mode gauge-adapter requires -adapter option")

   ;  if (!(input = myfopen(g_fnin, "r", 1)))
      X_ERR_JUMP(DONE, "bailing out (cannot read -i file)")

   ;  if (fndata && !(df.fpdata = myfopen(fndata, gzopenmode, 1)))
      X_ERR_JUMP(DONE, "cannot open data output file")

   ;  if (!(df.fpaccept = myfopen(fnout, "w", 0)))
      X_ERR_JUMP(DONE, "cannot open main output file")

   ;  if (fndebug && !(df.fpdebug = myfopen(fndebug, "w", 0)))
      X_ERR_JUMP(DONE, "cannot open debug output file")

   ;  output_settings(&df)

   ;  {  int i
      ;  df.n_ls = 1 << (2 * df.k)
      ;  if (!(ls = calloc(df.n_ls, sizeof ls[0])))
         X_ERR_JUMP(DONE, "cannot alloc kmer array")
      ;  argh
         (  "minion"
         ,  "malloc'ed %.1fG, unit size %d"
         ,  (double) ((df.n_ls * 1.0 * sizeof ls[0]) / (1.0 * (1 << 30)))
         ,  ji sizeof ls[0]
         )
      ;  for (i=0;i<df.n_ls;i++)
         ls[i].kmer = i
      ;  df.kmask = (1 << 2*df.k) - 1
      ;  df.ls = ls
      ;  argh("minion", "now possess %u fine fields, %lu", ju df.n_ls, lu df.kmask)
   ;  }

      {  unsigned n_bases_read = 0, n_bases_removed = 0
      ;  ctr countinfo[2] = { 0 }
      ;  unsigned n_reads = 0, n_broken_reads = 0, n_kmers_skipped = 0
      ;  argh("minion", "reading reads")
      ;  while (1)
         {  char readbuf[1024]
         ;  unsigned count = 1, n_skipped = 0
         ;  char* receive = readbuf

         ;  if (g_format_in)
            {  receive = rec.seq

            ;  unsigned tallystat = read_record3(input, &fb1, g_format_in, &rec)

            ;  if (rec.ID && rec.ID <= id_prev)
               X_ERR_JUMP(DONE, "i-file %s record IDs not increasing (%u follows %u)\n", g_fnin, ju rec.ID, ju id_prev)
            ;  id_prev = rec.ID
            ;  if (tallystat == MINION_DONE)
               break
            ;  else if (tallystat == MINION_NOMEM || tallystat == MINION_ERROR)
               goto DONE
            ;  count = rec.count
            ;  nread++
            ;  n_bases_read += rec.seq_n

            ;  if (++n_reads % 1000000 == 0)
               fprintf(stderr, "%3d\n", n_reads/1000000)
            ;  else if (n_reads % 20000 == 0)
               fputc('.', stderr)

            ;  if (df.tailtri)
               {  int max = 0, maxid = 0
               ;  do
                  {  dustscore_tail(rec.seq, rec.seq_n, NULL, &max, &maxid)
                  ;  if (max >= df.tailtri)
                        rec.seq[maxid] = '\0'
                     ,  n_bases_removed += (rec.seq_n - maxid)
                     ,  rec.seq_n = maxid
               ;  }
                  while (max >= df.tailtri)
   ;if(0)fprintf(stdout, "read seq [%s] %d:%d\n", rec.seq, ji maxid, ji max)
            ;  }
               n_skipped = parse_sequence(&df, rec.seq, rec.seq_n, rec.count, nread, countinfo)
            ;  n_broken_reads  += (n_skipped > 0)
            ;  n_kmers_skipped += n_skipped
            ;  if (n_reads == limit)
               break
         ;  }
         }
         if (n_reads % 1000000) fputc('\n', stderr)
      ;  argh
         (  "minion"
         ,  "have %u reads, removed %u bases by dusting (%.1f%% of total)"
         ,  ju n_reads
         ,  ju n_bases_removed
         ,  n_bases_removed * 100.0 / n_bases_read
         )
      ;  argh
         (  "minion"
         ,  "skipped %u kmers in %u reads (%.1f average)"
         ,  ju n_kmers_skipped
         ,  ju n_broken_reads
         ,  n_broken_reads ? n_kmers_skipped * 1.0 / n_broken_reads : 0.0
         )
      ;  argh
         (  "minion"
         ,  "have %.1fM total and %.1fM unique kmers (average %.1f)"
         ,  countinfo[0] / 1000000.0
         ,  countinfo[1] / 1000000.0
         ,  countinfo[0] * 1.0 / countinfo[1]
         )
   ;  }

      if (minionmode == 'a')           /*    gauge-adapter     */
      {  int i = 0
      ;  int l = strlen(theaptr)
      ;  unsigned mask = 0
      ;  unsigned kmer_prev = 0

      ;  for (i=0; i<=l-df.k; i++)
         {  unsigned kmer = kmer_from_buf(theaptr+i, df.k, &mask)
         ;  unsigned nextbase = 0, lastbase = themap[(unsigned char) theaptr[i+df.k-1]]
         ;  unsigned a_kmer =   kmer >> 2
         ;  unsigned c_kmer =  (kmer >> 2 ) | (1 << (2 * df.k -2))
         ;  unsigned g_kmer =  (kmer >> 2 ) | (2 << (2 * df.k -2))
         ;  unsigned t_kmer =  (kmer >> 2 ) | (3 << (2 * df.k -2))

         ;  if (i < l-df.k)
            nextbase = themap[(unsigned char) theaptr[i+df.k]]

;if (nextbase > 3)
 die(1, "minion")
         ;  fprintf
            (  stderr
            ,  "%.*s to %.*u [ %7d %7d %7d %7d ]  [ %7d %7d %7d %7d ]  %u %u\n"
            ,  df.k
            ,  theaptr+i
            ,  df.k
            ,  kmer
            ,  (int) (0.5 + (1000000.0 * df.ls[a_kmer].ttr[lastbase]) / df.ls[kmer_prev].ttr[lastbase])
            ,  (int) (0.5 + (1000000.0 * df.ls[c_kmer].ttr[lastbase]) / df.ls[kmer_prev].ttr[lastbase])
            ,  (int) (0.5 + (1000000.0 * df.ls[g_kmer].ttr[lastbase]) / df.ls[kmer_prev].ttr[lastbase])
            ,  (int) (0.5 + (1000000.0 * df.ls[t_kmer].ttr[lastbase]) / df.ls[kmer_prev].ttr[lastbase])

            ,  (int) (0.5 + (1000000.0 * df.ls[kmer].ttr[0]) / df.ls[kmer].ttr[nextbase])
            ,  (int) (0.5 + (1000000.0 * df.ls[kmer].ttr[1]) / df.ls[kmer].ttr[nextbase])
            ,  (int) (0.5 + (1000000.0 * df.ls[kmer].ttr[2]) / df.ls[kmer].ttr[nextbase])
            ,  (int) (0.5 + (1000000.0 * df.ls[kmer].ttr[3]) / df.ls[kmer].ttr[nextbase])
            ,  df.ls[kmer].nin
            ,  df.ls[kmer].nout
            )
         ;  kmer_prev = kmer
      ;  }
         exit(0)
   ;  }

      {  ctr siftinfo[6] = { 0 }
      ;  if (df.kmertri || df.io_omin || df.io_imin)
         {  sift(&df, siftinfo)
         ;  argh
            (  "minion"
            ,  "removed %.1fM total and %.1fM unique kmers below threshold (average %.1f)"
            ,  siftinfo[2] / 1000000.0
            ,  siftinfo[3] / 1000000.0
            ,  siftinfo[2] * 1.0 / siftinfo[3]
            )
         ;  argh
            (  "minion"
            ,  "retained %.1fM total and %.1fM unique kmers (average %.1f)"
            ,  siftinfo[4] / 1000000.0
            ,  siftinfo[5] / 1000000.0
            ,  siftinfo[4] * 1.0 / siftinfo[5]
            )
      ;  }

         argh("minion", "sorting by frequency")
      ;  get_top_by_out(&df, siftinfo[5])                /* fixme; heap no longer necessary */

      ;  annotate_top(&df)

      ;  df.ccannot = calloc(N_TRACK_CCANNOT, sizeof df.ccannot[0])

      ;  {        argh("minion", "connected component analysis")
         ;  compute_cc(&df)
         ;        argh("minion", "building consensus sequences")
         ;  trace_sequences(&df, df.n_max_sources)
      ;  }
      }

      status = 0
   ;  DONE
      :

      if (input)
      myfzclose(input, 1)

   ;  myfzclose(df.fpdata, zippit)
   ;  myfzclose(df.fpaccept, 0)
   ;  myfzclose(df.fpdebug, 0)

   ;  return status
;  }


int main
(  int argc
,  const char* argv[]
)
   {  return minion_main(argc, argv)
;  }




