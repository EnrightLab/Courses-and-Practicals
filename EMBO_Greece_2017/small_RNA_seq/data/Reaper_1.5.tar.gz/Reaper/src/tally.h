
#ifndef  include_tally
#define  include_tally

int tally_main
(  int argc
,  const char* argv[]
)  ;

#endif

