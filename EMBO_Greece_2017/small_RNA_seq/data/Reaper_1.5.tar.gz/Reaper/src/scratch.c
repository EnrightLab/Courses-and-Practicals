
#if 0
unsigned spread_your_wings
(  struct df *df
,  unsigned kmer
,  unsigned* stack
)
   {  int i_stack = 1, n_seen = 1
   ;  unsigned kmask = df->kmask
   ;  unsigned k     = df->k
   ;  stack[0] = kmer
   ;  char buf[64]
   ;  char buf2[64]

   ;  fillbuf(buf, kmer, k)
;fprintf(stderr, "start %s\n", buf)
   ;  while (i_stack > 0)
      {  unsigned thismer = stack[i_stack-1], j
      ;  unsigned n_left = 0, n_right = 0
      ;  i_stack--
      ;  for (j=0;j<4;j++)
         {  unsigned ttr   =  ((thismer << 2) | j) & kmask        /* to the right */
         ;  unsigned ttl   =  ((thismer >> 2) | (j << (2*k-2))) & kmask
         ;  int ho_r       =  df->ls[ttr].heap_offset
         ;  int ho_l       =  df->ls[ttl].heap_offset
         ;  struct kannot* an_r = ho_r >= 0 ? df->ws+ho_r : NULL
         ;  struct kannot* an_l = ho_l >= 0 ? df->ws+ho_l : NULL
         ;  if (an_r && !an_r->flags)        /* A) */
            {  const char* msg = "skip"
            ;  an_r->flags |= X_CC
            ;  fillbuf(buf2, ttr, k)
            ;  if
               (  df->ls[ttr].in >=  5
               && df->ls[ttr].out >= 5
               && an_r->in_out_ratio < 1.5
               && an_r->in_out_ratio > 0.5
               )
               {  stack[i_stack++] = ttr
               ;  n_seen++
               ;  n_right++
               ;  msg = "pickr"
            ;  }
fprintf(stderr, "%s from %s to %s in %d out %d\n", msg, buf, buf2, (int) df->ls[ttr].in, (int) df->ls[ttr].out);
            }
            if (an_l && !an_l->flags)        /* B) */
            {  const char* msg = "skip"
            ;  an_l->flags |= X_CC
            ;  fillbuf(buf2, ttl, k)
            ;  if
               (  df->ls[ttl].in  >=  5
               && df->ls[ttl].out >=  5
               && an_l->in_out_ratio < 1.5
               && an_l->in_out_ratio > 0.5
               )
               {  stack[i_stack++] = ttl
               ;  n_seen++
               ;  n_left++
               ;  msg = "pickl"
            ;  }
fprintf(stderr, "%s from %s to %s in %d out %d\n", msg, buf, buf2, (int) df->ls[ttl].in, (int) df->ls[ttl].out);
            }
         }
fillbuf(buf, thismer, k);
if (!n_right) fprintf(stderr, "sink %s\n", buf);
if (!n_left) fprintf(stderr, "source %s\n", buf);
fprintf(stderr, "--\n");
      }
      return n_seen
;  }
#endif



#if 0
unsigned start_of_sequence
(  unsigned kmer
,  struct df* df
)
   {  struct kmer* ls = df->ls
   ;  unsigned dictsize = df->n_ls
   ;  struct kannot* ws = df->ws
   ;  unsigned topsize = df->n_ws
   ;  unsigned k = df->k
   ;  char buf[64] = { 0 }
   ;  int x = 0

   ;  while(kmer > 0 && ls[kmer].heap_offset >=0)
      {  int ho = ls[kmer].heap_offset
      ;  fillbuf(buf, kmer, k)
;if(0)fprintf(stderr, "%s out %d p-skew %5.1f i/o ratio %5.1f offset %d\n", buf, (int) ls[kmer].out, ws[ho].prefix_skew, ws[ho].in_out_ratio, ho)
;if(df->options & OPT_ACCEPT_VERBOSE)fprintf(df->fpaccept, "< %s %u %g %d\n", buf, ls[kmer].in, ws[ho].in_out_ratio, x)

      ;  if (ws[ho].in_out_ratio <= df->io_rmin)
         break
      ;  {  unsigned next = get_best_prefix(kmer, ls, dictsize, ws, topsize, k)
;if(1)fprintf(stderr, "next %u\n", next)
         ;  if (!next)
            break
         ;  else
            kmer = next
      ;  }
         if (x++ >= 100)            /* fixme magic constant */
         break
   ;  }
      return kmer
;  }
#endif


#if 0

void do_stuff
(  struct df* df
,  int N
)
   {  unsigned i = 0, start, n_hit = 0
   ;  unsigned topsize = df->n_ws
   ;  char buf[512]

   ;  argh("minion", "stuff")
   ;  while (n_hit < N)
      {  int ho = -1
      ;  int n_variants = 0
      ;  while (i < topsize && (df->ws[i].flags))
         i++
      ;  if (i >= topsize)
         break
      ;  start = start_of_sequence(df->ws[i].kmer, df)

      ;  ho = df->ls[start].heap_offset
      ;  if (ho < 0 || df->ws[ho].flags)          /* fixme fix semantics of flags */
         {  i++
         ;  continue
      ;  }
         df->ws[ho].flags |= X_SEEN | X_BUSY      /* bit 1: seen bit 2: accepted root bit 4: busy. */
      ;  fillbuf(buf, start, df->k)
      ;  if (!adapter_g && !n_hit && (df->options & OPT_SEARCH_ADAPTER))
         adapter_g = start
      ;  n_hit += unroll_sequence(buf, 511, df->k, &n_variants, start, start, df)
      ;  df->ws[ho].flags ^= X_BUSY
   ;  }
      argh("minion", "ffuts")
;  }

unsigned unroll_sequence
(  char* buf
,  int n_buf
,  int i_buf            /* write next base here */
,  int* n_variants
,  unsigned root
,  unsigned kmer
,  struct df* df
)
   {  struct kmer* ls = df->ls
   ;  struct kannot* ws = df->ws
   ;  unsigned kmask = df->kmask
 
   ;  int ret = 0

   ;  unsigned dnabits = consider_shift(kmer, df)
   ;  unsigned n_consider = dnabits & 3

   ;  int n = 0

   ;  if (i_buf == n_buf || n_variants[0] >= 50)                  /* fixme magic constant */
      return 0

;if(1)fprintf(df->fpaccept, "ze bit are %u\n", dnabits)

   ;  if (!n_consider)
      {  buf[i_buf] = '\0'
      ;  if (test_sequence("sharp drop-off", buf, i_buf, n_variants[0], root, kmer, df, NULL))
         {  n_variants[0]++
         ;  ws[ls[root].heap_offset].flags |= X_SOURCE
         ;  ret++ 
      ;  }
         else
         {  if (0)fprintf(stderr, "reject %s\n", buf)
         ;  return 0
      ;  }
      }

                              /* fixme: if accepted with prefix, the prefix can be something
                               * previously discarded -- ideally check on accepted only
                              */
      while (n_consider-- > 0)
      {  unsigned j
      ;  dnabits = dnabits >> 2
      ;  j = dnabits & 3

      ;  unsigned shiftmer = (kmer << 2 | j) & kmask 
      ;  struct kannot* shiftannot = ws+ls[shiftmer].heap_offset    /* consider_shift should have checked shiftmer in ws */

      ;  if (shiftannot->flags & X_BUSY)           /* already seen in this consensus read */
         continue                                  /* fixme: warn? */
      ;  shiftannot->flags  |= X_BUSY

      ;  buf[i_buf] = dna[j]
      ;  buf[i_buf+1] = '\0'
      ;  n++

                                                   /* bit 2: start of consensus sequence already accepted */
      ;  if (shiftannot->flags & X_SOURCE)
         {  if (test_sequence("prefix", buf, i_buf+1, n_variants[0], root, shiftmer, df, shiftannot))
            {  n_variants[0]++
            ;  ws[ls[root].heap_offset].flags |= X_SOURCE
            ;  ret++
         ;  }
         }
         else
         {  shiftannot->flags |= X_SEEN
         ;  if (shiftannot->in_out_ratio > df->io_rmax)
            {  if (test_sequence("drop-off", buf, i_buf+1, n_variants[0], root, shiftmer, df, shiftannot))
               {  n_variants[0]++
               ;  ws[ls[root].heap_offset].flags |= X_SOURCE
               ;  ret++
            ;  }
            }
            else
            ret += unroll_sequence(buf, n_buf, i_buf+1, n_variants, root, shiftmer, df)
      ;  }
         shiftannot->flags ^= X_BUSY
   ;  }
      return ret
;  }

#endif






                                    /* fixme; bit expensive perhaps to recurse for traversal.
                                     * It's very convenient though.
                                    */
unsigned unroll_sequence2
(  char* buf
,  int n_buf
,  int i_buf            /* write next base here */
,  int* n_variants
,  int* n_cycle
,  unsigned root
,  unsigned kmer
,  struct df* df
)
   {  struct kmer* ls = df->ls
   ;  struct kannot* ws = df->ws
   ;  unsigned kmask = df->kmask
 
   ;  int ret = 0

   ;  unsigned dnabits = consider_shift(kmer, df)
   ;  unsigned n_consider = dnabits & 3

   ;  int n = 0

   ;  if (i_buf == n_buf || n_variants[0] >= df->n_variant_max)                  /* fixme magic constant */
      return 0

   ;  buf[i_buf] = '\0'

;if(1)fprintf(df->fpaccept, "bit %2u buf %s\n", dnabits, buf)

   ;  if (!n_consider)
      {  if (test_sequence("sharp drop-off", buf, i_buf, n_variants[0], n_cycle[0], root, kmer, df, NULL))
         {  n_variants[0]++
         ;  ret++ 
      ;  }
         else
         return 0
   ;  }

                              /* fixme: if accepted with prefix, the prefix can be something
                               * previously discarded -- ideally check on accepted only
                              */
      while (n_consider-- > 0)
      {  unsigned j
      ;  dnabits = dnabits >> 2
      ;  j = dnabits & 3

      ;  unsigned shiftmer = (kmer << 2 | j) & kmask 
      ;  struct kannot* shiftannot = ws+ls[shiftmer].heap_offset    /* consider_shift should have checked shiftmer in ws */

      ;  if (shiftannot->flags & X_BUSY)           /* already seen in this consensus read */
         {  n_cycle[0]++
;if (df->fpdebug)fprintf(df->fpaccept, "cycle\n")
         ;  continue
      ;  }
         shiftannot->flags  |= X_BUSY

      ;  buf[i_buf] = dna[j]
      ;  buf[i_buf+1] = '\0'
      ;  n++

                                                   /* start of consensus sequence already accepted */
      ;  if (shiftannot->flags & X_SOURCE)
         {  if (test_sequence("prefix", buf, i_buf+1, n_variants[0], n_cycle[0], root, shiftmer, df, shiftannot))
            {  n_variants[0]++
            ;  ret++
         ;  }
         }
         else
         {  shiftannot->flags |= X_SEEN
                                                   /* if (shiftannot->in_out_ratio > df->io_rmax) */
         ;  if
            (! (  df->ls[shiftmer].out >= df->io_omin
               && shiftannot->in_out_ratio <= df->io_rmax            /* tieme to  expand_component tieme */
               && shiftannot->in_out_ratio >= df->io_rmin            /* tieme to  expand_component tieme */
               )
            )
            {  if (test_sequence("drop-off", buf, i_buf+1, n_variants[0], n_cycle[0], root, shiftmer, df, shiftannot))
               {  n_variants[0]++
               ;  ret++
            ;  }
            }
            else
            ret += unroll_sequence2(buf, n_buf, i_buf+1, n_variants, n_cycle, root, shiftmer, df)
      ;  }
         shiftannot->flags ^= X_BUSY
   ;  }
      return ret
;  }


                           /* return value:
                                 bits 01  # of bases accepted.
                                 bits 12  highest frequency base
                                 bits 34  second highest frequency base
                                 bits 56  third highest frequency base
                                 bits 78  fourth highest frequency base.
                           */
unsigned consider_shift
(  unsigned kmer
,  struct df* df
)
   {  unsigned* ttr = df->ls[kmer].ttr
   ;  unsigned kmask = df->kmask
   ;  unsigned char nb[4] = { 0, 1, 2, 3 }            /* next base, ordered by cardinality */
   ;  unsigned swap = 0
   ;  unsigned n = 0
   ;  unsigned dnabits = 0
   ;  int i

                                                      /* below is explicit network sort for 4 elements */
   ;  if (ttr[1] > ttr[0])
         nb[0] = 1         /* utilise that we know the starting position */
      ,  nb[1] = 0
   ;  if (ttr[3] > ttr[2])
         nb[2] = 3         /* utilise that we know the starting position */
      ,  nb[3] = 2
   ;  if (ttr[nb[2]] > ttr[nb[0]])
         swap  = nb[0]
      ,  nb[0] = nb[2]
      ,  nb[2] = swap
   ;  if (ttr[nb[3]] > ttr[nb[1]])
         swap  = nb[1]
      ,  nb[1] = nb[3]
      ,  nb[3] = swap
   ;  if (ttr[nb[2]] > ttr[nb[1]])
         swap  = nb[1]
      ,  nb[1] = nb[2]
      ,  nb[2] = swap

                                    /* fixme: use information provided by expand_component */
   ;  for (i=0;i<4;i++)
      {  unsigned shiftmer = ((kmer << 2) | nb[i]) & kmask
      ;  int ho = df->ls[shiftmer].heap_offset
      ;  int tl = test_link_right(df, nb[i], kmer)
      ;  if (ho < 0 || !tl)
         continue
#if 0
      ;  if (!df->ws[ho].flags & X_CC)
            argh("bug", "link but no cc for %s\n", buf)
         ,  exit(0)
#endif
      ;  dnabits = dnabits | (nb[i] << (2 * i))
      ;  n++
   ;  }
      return (dnabits << 2) | n
;  }

int test_link_right
(  struct df *df
,  unsigned base_right
,  unsigned a
)
   {  unsigned b = (a << 2 | base_right) & df->kmask
#if DEBUG_ON
   ;  if (0)
      fprintf(df->fpdebug, "right %d %d %d %d\n", (int) base_right, (int) df->ls[a].ttr[base_right], df->ls[a].out, df->ls[b].out)
#endif
   ;  if
      (  df->ls[a].ttr[base_right] * 1.0 >= df->io_fmin * df->ls[a].out
      && df->ls[a].ttr[base_right] * 1.0 >= df->io_fmin * df->ls[b].out
      )
      return 1
   ;  return 0
;  }



int test_link_left
(  struct df *df
,  unsigned base_left
,  unsigned b
)
   {  unsigned a = (b >> 2 | (base_left << (2 * df->k-2))) & df->kmask
   ;  unsigned base_right = b & 3
#if DEBUG_ON
   ;  if (df->fpdebug)
      fprintf(df->fpdebug, "left %d %d\n", (int) base_right, (int) df->ls[a].ttr[base_right])
#endif
   ;  if
      (  df->ls[a].ttr[base_right] * 1.0 / df->ls[a].out >= df->io_fmin
      && df->ls[a].ttr[base_right] * 1.0 / df->ls[b].in  >= df->io_fmin
      )
      return 1
   ;  return 0
;  }




void put_on_top
(  struct df* df
,  unsigned kmer
)
   {  int ho = df->ls[kmer].heap_offset
   ;  struct kannot tmp = df->ws[0]
   ;  if (ho < 0)
      argh("#E#R#R#O#R", "%u not found", kmer)
   ;  df->ws[0]  =  df->ws[ho]
   ;  df->ws[ho] =  tmp
   ;  df->ls[kmer].heap_offset = 0
   ;  df->ls[tmp.kmer].heap_offset = ho
;  }
